#!/usr/bin/env python3
"""
main.py
=======
Entry point for ProSecToolkit — a defensive security assessment toolkit.

Usage:
    python main.py

ProSecToolkit is intended ONLY for assessing systems and networks that
you own or have explicit, documented authorization to test. On startup,
the user must acknowledge this policy before any scanning functionality
becomes available.

This file is intentionally thin: it wires together configuration,
logging, and the interactive menu system defined in `core/menu.py`.
"""

from __future__ import annotations

import sys

from config import APP_NAME, APP_VERSION, APP_TAGLINE, AUTHORIZATION_NOTICE, DEFAULT_CONFIG
from core.logger import get_logger
from core.config_manager import load_config
from core.colors import Colors
from core.menu import MainMenu


def print_banner() -> None:
    """Print the application banner and authorization notice."""
    banner = rf"""
{Colors.CYAN}{Colors.BOLD}
 ____                _____           _____           _ _    _ _
|  _ \ _ __ ___  ___|_   _|__  ___  |_   _|__   ___ | | | _(_) |_
| |_) | '__/ _ \/ __| | |/ _ \/ __|   | |/ _ \ / _ \| | |/ / | __|
|  __/| | | (_) \__ \ | |  __/ (__    | | (_) | (_) | |   <| | |_
|_|   |_|  \___/|___/ |_|\___|\___|   |_|\___/ \___/|_|_|\_\_|\__|
{Colors.RESET}
{Colors.BOLD}{APP_NAME} v{APP_VERSION} — {APP_TAGLINE}{Colors.RESET}
"""
    print(banner)


def confirm_authorization() -> bool:
    """
    Require explicit user acknowledgement of the authorized-use policy
    before allowing access to any scanning or assessment functionality.

    Returns:
        bool: True if the user acknowledges and accepts the policy.
    """
    print(f"{Colors.YELLOW}{AUTHORIZATION_NOTICE}{Colors.RESET}\n")
    try:
        response = input(
            "Type 'yes' to confirm you are authorized to assess your intended "
            "target(s), or anything else to exit: "
        ).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nExiting.")
        return False

    return response == "yes"


def main() -> int:
    """Application entry point. Returns a process exit code."""
    logger = get_logger("main")
    print_banner()

    if not confirm_authorization():
        print(f"{Colors.RED}Authorization not confirmed. Exiting.{Colors.RESET}")
        logger.info("User declined authorization notice; exiting.")
        return 1

    logger.info("Authorization confirmed. Loading configuration.")
    config = load_config(DEFAULT_CONFIG)

    try:
        menu = MainMenu(config=config, logger=logger)
        menu.run()
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Interrupted by user. Exiting.{Colors.RESET}")
        logger.info("Application interrupted by user (KeyboardInterrupt).")
        return 130
    except Exception as exc:  # noqa: BLE001 - top-level safety net
        logger.exception("Unhandled exception in main application loop.")
        print(f"{Colors.RED}A fatal error occurred: {exc}{Colors.RESET}")
        print("See logs/ for details.")
        return 1

    logger.info("ProSecToolkit exited normally.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
