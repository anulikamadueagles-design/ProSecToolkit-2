"""
modules/http_analyzer.py — HTTP response, redirect, and server-info analysis.

Fetches a URL and inspects the response: status code, headers, server
banner, and redirect chain. This is passive analysis of responses the
server chooses to send — no fuzzing, exploitation, or payload injection.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import requests

from config import AppConfig


@dataclass
class RedirectHop:
    url: str
    status_code: int


@dataclass
class HTTPAnalysis:
    url: str
    final_url: str | None = None
    status_code: int | None = None
    headers: dict[str, str] = field(default_factory=dict)
    server_banner: str | None = None
    redirect_chain: list[RedirectHop] = field(default_factory=list)
    elapsed_ms: float | None = None
    error: str | None = None


def analyze_url(url: str, config: AppConfig, logger: logging.Logger) -> HTTPAnalysis:
    """
    Fetch `url` and return structured details about the HTTP response,
    including any redirect chain followed to reach the final destination.

    Args:
        url: Full URL to analyze (should include scheme, e.g. https://).
        config: Application configuration (uses scan.http_timeout).
        logger: Logger for diagnostic output.
    """
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    try:
        response = requests.get(
            url,
            timeout=config.scan.http_timeout,
            allow_redirects=True,
            headers={"User-Agent": "ProSecToolkit/1.0 (defensive-assessment)"},
        )
    except requests.exceptions.RequestException as exc:
        logger.warning("HTTP request failed for %s: %s", url, exc)
        return HTTPAnalysis(url=url, error=str(exc))

    redirect_chain = [
        RedirectHop(url=resp.url, status_code=resp.status_code) for resp in response.history
    ]

    analysis = HTTPAnalysis(
        url=url,
        final_url=response.url,
        status_code=response.status_code,
        headers=dict(response.headers),
        server_banner=response.headers.get("Server"),
        redirect_chain=redirect_chain,
        elapsed_ms=round(response.elapsed.total_seconds() * 1000, 2),
    )

    logger.info(
        "HTTP analysis complete for %s: status=%s, redirects=%d",
        url, analysis.status_code, len(redirect_chain),
    )
    return analysis
