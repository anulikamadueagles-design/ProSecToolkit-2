
"""Local banking simulator for security testing.

This module deliberately never connects to a bank, payment processor, card
network, or real account. It provides realistic authorization/transfer flows
for testing the toolkit without moving real money.
"""
from __future__ import annotations

import secrets
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from config import BASE_DIR
def _cancelled(value):
    return str(value).strip().lower() in {'0','back','cancel','q','quit'}

DB_PATH = BASE_DIR / "banking_simulator.db"

@dataclass
class Account:
    account_number: str
    owner: str
    balance: int

@dataclass
class TransferResult:
    success: bool
    transaction_id: str
    message: str
    balance: int | None = None

_SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    account_number TEXT PRIMARY KEY,
    owner TEXT NOT NULL,
    balance INTEGER NOT NULL CHECK(balance >= 0),
    pin_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id TEXT UNIQUE NOT NULL,
    sender TEXT NOT NULL,
    recipient TEXT NOT NULL,
    amount INTEGER NOT NULL CHECK(amount > 0),
    created_at TEXT NOT NULL,
    status TEXT NOT NULL
);
"""

def _db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(_SCHEMA)
    return conn

def _hash_pin(pin: str) -> str:
    # PBKDF2 is standard-library only and adequate for this local simulator.
    import hashlib
    return hashlib.pbkdf2_hmac("sha256", pin.encode(), b"prosec-sim-v1", 120_000).hex()

def create_account(account_number: str, owner: str, balance: int, pin: str) -> None:
    if not account_number.isdigit() or not (4 <= len(account_number) <= 20):
        raise ValueError("Account number must contain 4-20 digits.")
    if balance < 0:
        raise ValueError("Balance cannot be negative.")
    with _db() as c:
        c.execute("INSERT INTO accounts VALUES (?, ?, ?, ?)", (account_number, owner, balance, _hash_pin(pin)))

def get_account(account_number: str, pin: str | None = None) -> Account:
    with _db() as c:
        row = c.execute("SELECT account_number, owner, balance, pin_hash FROM accounts WHERE account_number=?", (account_number,)).fetchone()
    if not row:
        raise ValueError("Test account not found.")
    if pin is not None and not secrets.compare_digest(row[3], _hash_pin(pin)):
        raise PermissionError("Authorization failed.")
    return Account(row[0], row[1], row[2])

def transfer(sender: str, recipient: str, amount: int, pin: str) -> TransferResult:
    if amount <= 0:
        return TransferResult(False, "", "Amount must be greater than zero.")
    txid = "SIM-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S") + "-" + secrets.token_hex(3).upper()
    try:
        with _db() as c:
            c.execute("BEGIN IMMEDIATE")
            s = c.execute("SELECT balance, pin_hash FROM accounts WHERE account_number=?", (sender,)).fetchone()
            r = c.execute("SELECT account_number FROM accounts WHERE account_number=?", (recipient,)).fetchone()
            if not s or not r:
                raise ValueError("Sender or recipient test account not found.")
            if not secrets.compare_digest(s[1], _hash_pin(pin)):
                raise PermissionError("Authorization failed.")
            if s[0] < amount:
                raise ValueError("Insufficient simulated funds.")
            c.execute("UPDATE accounts SET balance=balance-? WHERE account_number=?", (amount, sender))
            c.execute("UPDATE accounts SET balance=balance+? WHERE account_number=?", (amount, recipient))
            c.execute("INSERT INTO transactions(transaction_id,sender,recipient,amount,created_at,status) VALUES(?,?,?,?,?,?)",
                      (txid, sender, recipient, amount, datetime.now(timezone.utc).isoformat(), "COMPLETED"))
            new_balance = s[0] - amount
        return TransferResult(True, txid, "SIMULATION TRANSFER COMPLETED", new_balance)
    except Exception as exc:
        return TransferResult(False, txid, str(exc))

def list_transactions(limit: int = 20):
    with _db() as c:
        return c.execute("SELECT transaction_id,sender,recipient,amount,created_at,status FROM transactions ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
