"""
Android/Linux Wi-Fi adapter for ProSecToolkit v1.1.1.

Security model:
- Scanning is passive discovery of nearby networks.
- Connection requires an SSID plus operator-supplied credentials.
- No password cracking, credential harvesting, or bypass is attempted.
- Android/Pydroid does not expose Linux nmcli; a native Android bridge is
  required for true Wi-Fi control.
"""

from __future__ import annotations
import os
import platform
import shutil
import subprocess
from dataclasses import dataclass


@dataclass
class WifiNetwork:
    ssid: str
    signal: str = "?"
    security: str = "Unknown"
    source: str = "unknown"


def is_android() -> bool:
    return (
        "ANDROID_ROOT" in os.environ
        or "ANDROID_DATA" in os.environ
        or "android" in platform.platform().lower()
    )


def _nmcli_available() -> bool:
    return shutil.which("nmcli") is not None


def scan_wifi() -> tuple[list[WifiNetwork], str | None]:
    """
    Returns (networks, error).

    Linux desktop with nmcli: perform a read-only scan.
    Android/Pydroid: return a clear native-bridge message rather than trying
    to execute an unavailable Linux utility.
    """
    if _nmcli_available():
        try:
            proc = subprocess.run(
                ["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list"],
                capture_output=True, text=True, timeout=15, check=False,
            )
            if proc.returncode != 0:
                return [], proc.stderr.strip() or "nmcli Wi-Fi scan failed."
            networks = []
            seen = set()
            for line in proc.stdout.splitlines():
                parts = line.split(":")
                if len(parts) < 3:
                    continue
                ssid, signal, security = parts[0].strip(), parts[1].strip(), parts[2].strip()
                if not ssid or ssid in seen:
                    continue
                seen.add(ssid)
                networks.append(WifiNetwork(ssid, signal, security, "nmcli"))
            return networks, None
        except (OSError, subprocess.SubprocessError) as exc:
            return [], f"nmcli scan failed: {exc}"

    if is_android():
        return [], (
            "Android/Pydroid detected: nmcli is not available. "
            "A native Android Wi-Fi bridge/APK component is required for "
            "real scanning and connection. The Python CLI cannot directly "
            "control Android Wi-Fi."
        )

    return [], (
        "No supported Wi-Fi backend found. Install NetworkManager/nmcli "
        "on a supported Linux host, or use the Android native build."
    )


def connect_authorized(ssid: str, password: str, security: str = "WPA2") -> tuple[bool, str]:
    """
    Connect only using credentials explicitly supplied by the operator.

    Linux: uses nmcli.
    Android/Pydroid: refuses to pretend it can connect; native Android
    implementation is required.
    """
    if not ssid.strip():
        return False, "SSID is required."
    if not password:
        return False, "Wi-Fi password is required for this connection flow."

    if _nmcli_available():
        try:
            proc = subprocess.run(
                ["nmcli", "dev", "wifi", "connect", ssid, "password", password],
                capture_output=True, text=True, timeout=30, check=False,
            )
            if proc.returncode == 0:
                return True, proc.stdout.strip() or "Connection requested successfully."
            return False, proc.stderr.strip() or "nmcli connection failed."
        except (OSError, subprocess.SubprocessError) as exc:
            return False, f"nmcli connection failed: {exc}"

    if is_android():
        return False, (
            "Android/Pydroid does not provide nmcli. "
            "Use the Android-native Wi-Fi bridge in the APK build; "
            "the Python CLI cannot directly connect Android Wi-Fi."
        )

    return False, "No supported Wi-Fi connection backend is installed."
