"""Assessment coverage statements.

These are deliberately marked NOT_ESTABLISHED: absence of a test is not proof
that a vulnerability is absent.
"""

def get_coverage_findings():
    categories = [
        ("SQL injection", "No SQL injection testing is implemented by this release."),
        ("XSS", "No cross-site scripting testing is implemented by this release."),
        ("Authentication bypass", "No authentication-bypass testing is implemented by this release."),
        ("RCE", "No remote-code-execution testing is implemented by this release."),
        ("SSRF", "No server-side request forgery testing is implemented by this release."),
        ("Account takeover", "No account-takeover testing is implemented by this release."),
        ("Data exposure", "No sensitive-data-exposure testing is implemented by this release."),
    ]
    return [{"category": c, "description": d, "recommendation": "Use a dedicated, authorized application-security test plan for this category.", "status": "NOT_ESTABLISHED"} for c, d in categories]
