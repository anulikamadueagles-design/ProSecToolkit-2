"""
modules/tls_analyzer.py — TLS protocol/cipher configuration analysis.

Connects to a host:port with TLS and inspects the negotiated protocol
version and cipher suite, flagging weak/deprecated configurations
(SSLv3, TLS 1.0/1.1, null/export/RC4/3DES ciphers, etc.). Read-only
handshake inspection only — no downgrade attacks or fuzzing.
"""

from __future__ import annotations

import logging
import socket
import ssl
from dataclasses import dataclass, field

from config import AppConfig

_WEAK_PROTOCOLS = {"SSLv2", "SSLv3", "TLSv1", "TLSv1.1"}
_WEAK_CIPHER_KEYWORDS = ("NULL", "EXPORT", "RC4", "3DES", "DES", "MD5", "anon")


@dataclass
class TLSFinding:
    description: str
    severity: str  # LOW | MEDIUM | HIGH


@dataclass
class TLSAnalysis:
    host: str
    port: int
    protocol: str | None = None
    cipher_name: str | None = None
    cipher_bits: int | None = None
    findings: list[TLSFinding] = field(default_factory=list)
    error: str | None = None


def analyze_tls(
    host: str,
    config: AppConfig,
    logger: logging.Logger,
    port: int = 443,
) -> TLSAnalysis:
    """
    Connect to host:port with TLS and inspect the negotiated protocol
    and cipher for common weaknesses.
    """
    context = ssl.create_default_context()
    # We want to inspect whatever the server offers, including weak
    # configs, so we don't hard-fail on older protocols here — the point
    # is to detect and report them, not to refuse to connect.
    context.check_hostname = True

    try:
        with socket.create_connection((host, port), timeout=config.scan.tls_timeout) as sock:
            with context.wrap_socket(sock, server_hostname=host) as tls_sock:
                cipher_name, protocol, cipher_bits = tls_sock.cipher()
                analysis = TLSAnalysis(
                    host=host, port=port,
                    protocol=protocol, cipher_name=cipher_name, cipher_bits=cipher_bits,
                )
    except ssl.SSLError as exc:
        logger.warning("TLS handshake failed for %s:%s: %s", host, port, exc)
        return TLSAnalysis(host=host, port=port, error=f"TLS handshake failed: {exc}")
    except (socket.timeout, OSError) as exc:
        logger.warning("Connection failed for %s:%s: %s", host, port, exc)
        return TLSAnalysis(host=host, port=port, error=f"Connection failed: {exc}")

    # Evaluate findings.
    if analysis.protocol in _WEAK_PROTOCOLS:
        analysis.findings.append(TLSFinding(
            description=f"Deprecated protocol negotiated: {analysis.protocol}. "
                        f"Disable in favor of TLS 1.2/1.3.",
            severity="HIGH",
        ))
    if analysis.cipher_name and any(kw in analysis.cipher_name.upper() for kw in _WEAK_CIPHER_KEYWORDS):
        analysis.findings.append(TLSFinding(
            description=f"Weak cipher suite negotiated: {analysis.cipher_name}.",
            severity="HIGH",
        ))
    if analysis.cipher_bits is not None and analysis.cipher_bits < 128:
        analysis.findings.append(TLSFinding(
            description=f"Low cipher strength: {analysis.cipher_bits}-bit.",
            severity="MEDIUM",
        ))
    if not analysis.findings:
        analysis.findings.append(TLSFinding(
            description="No weak protocol/cipher issues detected in negotiated session.",
            severity="LOW",
        ))

    logger.info(
        "TLS analysis complete for %s:%s — protocol=%s cipher=%s",
        host, port, analysis.protocol, analysis.cipher_name,
    )
    return analysis
