"""Security-header analysis; missing headers are hardening observations, not automatic high risk."""
from __future__ import annotations
from dataclasses import dataclass
@dataclass
class HeaderFinding:
    header:str; present:bool; value:str|None; recommendation:str; severity:str; status:str="OBSERVED"; title:str=""; evidence:str=""
_CHECKS=[
("Strict-Transport-Security","LOW","Consider HSTS after confirming HTTPS coverage."),
("Content-Security-Policy","LOW","Define a restrictive CSP appropriate for the application."),
("X-Content-Type-Options","LOW","Add X-Content-Type-Options: nosniff."),
("X-Frame-Options","LOW","Add X-Frame-Options or CSP frame-ancestors."),
("Referrer-Policy","LOW","Consider strict-origin-when-cross-origin or stricter."),
("Permissions-Policy","LOW","Restrict browser capabilities the application does not need."),]
def evaluate_headers(headers:dict[str,str])->list[HeaderFinding]:
    h={str(k).lower():str(v) for k,v in headers.items()}; out=[]
    for name,sev,rec in _CHECKS:
        present=name.lower() in h; val=h.get(name.lower())
        out.append(HeaderFinding(name,present,val,"Present." if present else rec,sev,"OBSERVED",f"{name} observed" if present else f"{name} not observed",f"{name}: {val}" if present else f"{name} was absent"))
    csp=h.get("content-security-policy","").lower()
    if not h.get("x-frame-options") and "frame-ancestors" in csp:
        f=next(x for x in out if x.header=="X-Frame-Options"); f.present=True; f.value="CSP frame-ancestors"; f.recommendation="Present via CSP frame-ancestors."; f.title="Framing protection observed"
    weak=[x for x in ("'unsafe-inline'","'unsafe-eval'") if x in csp]
    if weak: out.append(HeaderFinding("Content-Security-Policy",True,h.get("content-security-policy"),"Review unsafe-inline/unsafe-eval; prefer nonces/hashes where feasible.","LOW","OBSERVED","CSP contains potentially weakening directives",", ".join(weak)))
    return out
def analyze_headers(headers,url=""): return evaluate_headers(headers)
def summarize(findings): return {s:sum(1 for f in findings if f.severity==s and not f.present) for s in ("LOW","MEDIUM","HIGH")}
