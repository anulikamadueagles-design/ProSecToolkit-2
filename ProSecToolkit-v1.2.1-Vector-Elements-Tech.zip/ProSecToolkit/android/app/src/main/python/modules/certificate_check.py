"""
modules/certificate_check.py — TLS certificate inspection and expiry checks.

Retrieves a server's TLS certificate and reports its subject, issuer,
validity window, and days remaining until expiration, flagging
certificates that are expired or expiring soon.
"""

from __future__ import annotations

import logging
import socket
import ssl
from dataclasses import dataclass, field
from datetime import datetime, timezone

from config import AppConfig

_EXPIRY_WARNING_DAYS = 30


@dataclass
class CertificateInfo:
    host: str
    port: int
    subject: str | None = None
    issuer: str | None = None
    not_before: str | None = None
    not_after: str | None = None
    days_until_expiry: int | None = None
    san_entries: list[str] = field(default_factory=list)
    status: str | None = None  # "valid" | "expiring_soon" | "expired"
    error: str | None = None


def _dn_to_str(dn_tuples) -> str:
    """Flatten an x509 DN (as returned by ssl getpeercert) to a readable string."""
    parts = []
    for rdn in dn_tuples:
        for key, value in rdn:
            parts.append(f"{key}={value}")
    return ", ".join(parts)


def check_certificate(
    host: str,
    config: AppConfig,
    logger: logging.Logger,
    port: int = 443,
) -> CertificateInfo:
    """
    Retrieve and inspect the TLS certificate presented by host:port.
    """
    context = ssl.create_default_context()

    try:
        with socket.create_connection((host, port), timeout=config.scan.tls_timeout) as sock:
            with context.wrap_socket(sock, server_hostname=host) as tls_sock:
                cert = tls_sock.getpeercert()
    except ssl.SSLCertVerificationError as exc:
        logger.warning("Certificate verification failed for %s:%s: %s", host, port, exc)
        return CertificateInfo(host=host, port=port, error=f"Certificate verification failed: {exc}")
    except (ssl.SSLError, socket.timeout, OSError) as exc:
        logger.warning("Could not retrieve certificate for %s:%s: %s", host, port, exc)
        return CertificateInfo(host=host, port=port, error=str(exc))

    if not cert:
        return CertificateInfo(host=host, port=port, error="No certificate returned.")

    not_after_raw = cert.get("notAfter")
    not_before_raw = cert.get("notBefore")
    days_remaining = None
    status = None

    if not_after_raw:
        expiry_dt = datetime.strptime(not_after_raw, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
        days_remaining = (expiry_dt - datetime.now(timezone.utc)).days
        if days_remaining < 0:
            status = "expired"
        elif days_remaining <= _EXPIRY_WARNING_DAYS:
            status = "expiring_soon"
        else:
            status = "valid"

    san_entries = [value for key, value in cert.get("subjectAltName", ()) if key == "DNS"]

    info = CertificateInfo(
        host=host, port=port,
        subject=_dn_to_str(cert.get("subject", ())),
        issuer=_dn_to_str(cert.get("issuer", ())),
        not_before=not_before_raw,
        not_after=not_after_raw,
        days_until_expiry=days_remaining,
        san_entries=san_entries,
        status=status,
    )

    logger.info(
        "Certificate check complete for %s:%s — status=%s, days_remaining=%s",
        host, port, status, days_remaining,
    )
    return info
