"""
modules/system_info.py — Local system information gathering.

Collects hostname, local IP addresses, network interfaces, and OS
details for the machine ProSecToolkit is running on. Uses `psutil` when
available for richer interface data, falling back to `socket`/`platform`
otherwise.
"""

from __future__ import annotations

import logging
import platform
import socket
from dataclasses import dataclass, field

try:
    import psutil
    _HAS_PSUTIL = True
except ImportError:  # pragma: no cover - psutil is in requirements.txt
    _HAS_PSUTIL = False


@dataclass
class InterfaceInfo:
    name: str
    addresses: list[str] = field(default_factory=list)
    is_up: bool | None = None


@dataclass
class SystemInfo:
    hostname: str
    local_ips: list[str] = field(default_factory=list)
    interfaces: list[InterfaceInfo] = field(default_factory=list)
    os_name: str = ""
    os_version: str = ""
    os_release: str = ""
    architecture: str = ""
    python_version: str = ""


def _get_local_ips(hostname: str) -> list[str]:
    """Best-effort collection of local (non-loopback) IP addresses."""
    ips: set[str] = set()
    try:
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if not ip.startswith("127.") and ip != "::1":
                ips.add(ip)
    except socket.gaierror:
        pass

    # Fallback trick: open a UDP "connection" to a public IP (no packets
    # are actually sent for UDP connect) to learn the outbound-facing
    # local address.
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ips.add(s.getsockname()[0])
    except OSError:
        pass

    return sorted(ips)


def _get_interfaces() -> list[InterfaceInfo]:
    """Enumerate network interfaces and their addresses."""
    interfaces: list[InterfaceInfo] = []

    if _HAS_PSUTIL:
        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
        for name, addr_list in addrs.items():
            ips = [a.address for a in addr_list if a.family in (socket.AF_INET, socket.AF_INET6)]
            is_up = stats[name].isup if name in stats else None
            interfaces.append(InterfaceInfo(name=name, addresses=ips, is_up=is_up))
    else:
        # Minimal fallback: we can't enumerate interface names portably
        # without psutil, so just report the primary hostname-resolved
        # addresses under a generic label.
        interfaces.append(InterfaceInfo(
            name="(interface enumeration requires psutil)",
            addresses=_get_local_ips(socket.gethostname()),
            is_up=None,
        ))

    return interfaces


def gather_system_info(logger: logging.Logger) -> SystemInfo:
    """Collect and return local system information."""
    hostname = socket.gethostname()

    info = SystemInfo(
        hostname=hostname,
        local_ips=_get_local_ips(hostname),
        interfaces=_get_interfaces(),
        os_name=platform.system(),
        os_version=platform.version(),
        os_release=platform.release(),
        architecture=platform.machine(),
        python_version=platform.python_version(),
    )

    logger.info("System info gathered for host '%s' (%s %s)", hostname, info.os_name, info.os_release)
    return info
