"""Authorized Wi-Fi discovery and connection helpers.

Discovery is read-only. Connection requires the operator to explicitly provide
credentials for a network they are authorized to use. No password cracking,
credential capture, deauthentication, or bypass is implemented.
"""
from __future__ import annotations

import logging
import platform
import re
import subprocess
from dataclasses import dataclass

@dataclass
class WiFiNetwork:
    ssid: str
    signal_percent: int | None = None
    security: str | None = None
    connected: bool = False

@dataclass
class WiFiAction:
    success: bool
    message: str


def _run(cmd: list[str], timeout: float = 10.0) -> tuple[int, str, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as exc:
        return 1, "", str(exc)


def scan_wifi(logger: logging.Logger) -> tuple[list[WiFiNetwork], str | None]:
    """Scan nearby Wi-Fi networks using the platform's native utility."""
    system = platform.system().lower()
    networks: list[WiFiNetwork] = []

    if system == "linux":
        code, out, err = _run(["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY", "dev", "wifi", "list"])
        if code:
            return [], f"nmcli scan unavailable: {err or 'command failed'}"
        for line in out.splitlines():
            parts = line.split(":")
            if len(parts) < 4:
                continue
            in_use, ssid, signal, security = parts[:4]
            if not ssid:
                continue
            networks.append(WiFiNetwork(ssid=ssid, signal_percent=int(signal) if signal.isdigit() else None,
                                        security=security or "Open", connected=in_use == "*"))
        return networks, None

    if system == "windows":
        code, out, err = _run(["netsh", "wlan", "show", "networks", "mode=bssid"])
        if code:
            return [], f"netsh Wi-Fi scan unavailable: {err or 'command failed'}"
        current_ssid = None
        for line in out.splitlines():
            m = re.match(r"\s*SSID\s+\d+\s*:\s*(.*)", line)
            if m:
                current_ssid = m.group(1).strip()
                continue
            m = re.match(r"\s*Signal\s*:\s*(\d+)%", line)
            if m and current_ssid:
                networks.append(WiFiNetwork(current_ssid, int(m.group(1))))
        return networks, None

    return [], ("Wi-Fi scanning is not available through the Python CLI on this platform. "
                "On Android/Pydroid, use the native Android Wi-Fi API from an APK or a supported bridge.")


def connect_authorized_wifi(ssid: str, password: str, security: str = "WPA2", logger: logging.Logger | None = None) -> WiFiAction:
    """Connect using credentials supplied by the authorized operator."""
    if not ssid.strip():
        return WiFiAction(False, "SSID is required.")
    if security.lower() not in {"open", "none"} and not password:
        return WiFiAction(False, "A network password is required for secured Wi-Fi.")

    system = platform.system().lower()
    if system == "linux":
        if security.lower() in {"open", "none"}:
            cmd = ["nmcli", "dev", "wifi", "connect", ssid]
        else:
            cmd = ["nmcli", "dev", "wifi", "connect", ssid, "password", password]
        code, out, err = _run(cmd, timeout=20)
        ok = code == 0
        msg = (out or err or ("Connected." if ok else "Connection failed.")).strip()
    elif system == "windows":
        return WiFiAction(False, "Windows requires a WLAN profile for programmatic connection; use the OS Wi-Fi UI or import an authorized profile.")
    else:
        return WiFiAction(False, "Direct Wi-Fi connection is not exposed by this Python CLI on this platform. Use the Android/OS Wi-Fi UI or a native app bridge.")

    if logger:
        logger.info("Wi-Fi connection request for SSID=%s success=%s", ssid, ok)
    return WiFiAction(ok, msg)
