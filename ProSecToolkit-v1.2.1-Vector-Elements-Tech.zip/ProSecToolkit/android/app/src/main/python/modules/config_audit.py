"""Normalize module output into evidence-aware audit findings."""
from __future__ import annotations
from dataclasses import dataclass
from modules.certificate_check import CertificateInfo
from modules.port_scan import PortResult
from modules.security_headers import HeaderFinding
from modules.tls_analyzer import TLSFinding

_RISKY_PORTS = {21:("FTP","Unencrypted file transfer."),23:("Telnet","Unencrypted remote administration."),111:("RPCBind","Review exposure if unused."),135:("MSRPC","Review exposure on untrusted networks."),139:("NetBIOS","Legacy file sharing."),445:("SMB","Frequently targeted when exposed."),1723:("PPTP","Deprecated VPN protocol."),3389:("RDP","High-value remote administration service."),5900:("VNC","Review authentication and exposure.")}

@dataclass
class AuditFinding:
    category: str
    description: str
    severity: str
    recommendation: str
    status: str = "OBSERVED"
    evidence: str = ""
    positive_control: bool = False

def audit_open_ports(open_ports):
    out=[]
    for r in open_ports:
        if r.port in _RISKY_PORTS:
            svc,why=_RISKY_PORTS[r.port]
            out.append(AuditFinding("Open Ports",f"Port {r.port} ({svc}) is open. {why}","HIGH",f"Disable {svc} if not required, or restrict access via firewall/VPN.","CONFIRMED",f"TCP port {r.port} accepted a connection."))
    if not out:
        out.append(AuditFinding("Open Ports",f"{len(open_ports)} open port(s) found; none matched the high-risk inventory.","INFO","Review the inventory to confirm every exposed service is intended.","OBSERVED",positive_control=True))
    return out

def audit_headers(header_findings):
    out=[]
    for f in header_findings:
        if not f.present:
            out.append(AuditFinding("HTTP Headers",f"Missing header: {f.header}",f.severity,f.recommendation,"OBSERVED",f"{f.header} was absent from the received response."))
        elif getattr(f,"title","") and "weakening" in f.title.lower():
            out.append(AuditFinding("HTTP Headers",f.title,f.severity,f.recommendation,"OBSERVED",getattr(f,"evidence", "")))
    if not out:
        out.append(AuditFinding("HTTP Headers","Checked security headers were observed.","INFO","Continue monitoring header configuration.","OBSERVED",positive_control=True))
    return out

def audit_tls(tls_findings):
    return [AuditFinding("TLS",f.description,f.severity,"Reconfigure deprecated protocols/ciphers and prefer strong TLS configuration.","CONFIRMED",f.description) for f in tls_findings]

def audit_certificate(cert):
    if cert.error:
        return [AuditFinding("Certificate",f"Certificate check could not complete: {cert.error}","INFO","Retry the certificate check or investigate connectivity.","ERROR",cert.error)]
    if cert.status == "expired":
        return [AuditFinding("Certificate",f"Certificate expired {abs(cert.days_until_expiry or 0)} day(s) ago.","HIGH","Renew the certificate immediately.","CONFIRMED",f"Validity ended at {cert.not_after}." )]
    if cert.status == "expiring_soon":
        return [AuditFinding("Certificate",f"Certificate expires in {cert.days_until_expiry} day(s).","MEDIUM","Schedule certificate renewal.","OBSERVED",f"Expires at {cert.not_after}." )]
    return [AuditFinding("Certificate",f"Certificate is currently valid for {cert.days_until_expiry} more day(s).","INFO","Continue monitoring certificate lifecycle.","OBSERVED",positive_control=True)]

def run_full_audit(open_ports=None,header_findings=None,tls_findings=None,certificate=None):
    out=[]
    if open_ports is not None: out.extend(audit_open_ports(open_ports))
    if header_findings is not None: out.extend(audit_headers(header_findings))
    if tls_findings is not None: out.extend(audit_tls(tls_findings))
    if certificate is not None: out.extend(audit_certificate(certificate))
    return out
