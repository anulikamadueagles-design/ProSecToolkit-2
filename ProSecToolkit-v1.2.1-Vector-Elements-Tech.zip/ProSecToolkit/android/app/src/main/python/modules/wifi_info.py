"""
modules/wifi_info.py — Local Wi-Fi adapter/connection information.

Reports details about the Wi-Fi network the current device is connected
to (SSID, signal strength, security type) using platform-native
utilities. This is passive, read-only inspection of the local machine's
own network connection — it does not scan or attack nearby networks.

Platform support varies:
  - Windows: `netsh wlan show interfaces`
  - Linux: `nmcli -t -f active,ssid,signal,security dev wifi` (if nmcli present)
  - macOS: `airport -I` (if available)
  - Android/Pydroid 3: generally unsupported without native APIs; returns
    an informative error instead of failing silently.
"""

from __future__ import annotations

import logging
import platform
import re
import subprocess
from dataclasses import dataclass


@dataclass
class WiFiInfo:
    connected: bool
    ssid: str | None = None
    signal_percent: int | None = None
    security: str | None = None
    error: str | None = None


def _run(cmd: list[str], timeout: float = 5.0) -> str | None:
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return result.stdout if result.returncode == 0 else None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None


def _windows_wifi_info() -> WiFiInfo:
    output = _run(["netsh", "wlan", "show", "interfaces"])
    if not output:
        return WiFiInfo(connected=False, error="Could not query wlan interfaces (netsh unavailable?).")

    ssid = re.search(r"^\s*SSID\s*:\s*(.+)$", output, re.MULTILINE)
    signal = re.search(r"^\s*Signal\s*:\s*(\d+)%", output, re.MULTILINE)
    security = re.search(r"^\s*Authentication\s*:\s*(.+)$", output, re.MULTILINE)

    if not ssid:
        return WiFiInfo(connected=False, error="Not connected to a Wi-Fi network.")

    return WiFiInfo(
        connected=True,
        ssid=ssid.group(1).strip(),
        signal_percent=int(signal.group(1)) if signal else None,
        security=security.group(1).strip() if security else None,
    )


def _linux_wifi_info() -> WiFiInfo:
    output = _run(["nmcli", "-t", "-f", "active,ssid,signal,security", "dev", "wifi"])
    if not output:
        return WiFiInfo(connected=False, error="nmcli unavailable or no Wi-Fi adapter found.")

    for line in output.splitlines():
        fields = line.split(":")
        if len(fields) >= 4 and fields[0].lower() == "yes":
            return WiFiInfo(
                connected=True,
                ssid=fields[1] or None,
                signal_percent=int(fields[2]) if fields[2].isdigit() else None,
                security=fields[3] or "Open",
            )
    return WiFiInfo(connected=False, error="Not currently connected to a Wi-Fi network.")


def _macos_wifi_info() -> WiFiInfo:
    airport = (
        "/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport"
    )
    output = _run([airport, "-I"])
    if not output:
        return WiFiInfo(connected=False, error="airport utility unavailable.")

    ssid = re.search(r"^\s*SSID:\s*(.+)$", output, re.MULTILINE)
    if not ssid:
        return WiFiInfo(connected=False, error="Not connected to a Wi-Fi network.")

    rssi = re.search(r"^\s*agrCtlRSSI:\s*(-?\d+)$", output, re.MULTILINE)
    signal_percent = None
    if rssi:
        # Rough RSSI(dBm) -> percentage conversion for display purposes.
        rssi_val = int(rssi.group(1))
        signal_percent = max(0, min(100, 2 * (rssi_val + 100)))

    return WiFiInfo(connected=True, ssid=ssid.group(1).strip(), signal_percent=signal_percent)


def get_wifi_info(logger: logging.Logger) -> WiFiInfo:
    """Return information about the current Wi-Fi connection, if any."""
    system = platform.system().lower()

    if system == "windows":
        info = _windows_wifi_info()
    elif system == "linux":
        info = _linux_wifi_info()
    elif system == "darwin":
        info = _macos_wifi_info()
    else:
        info = WiFiInfo(connected=False, error=f"Wi-Fi info not supported on platform '{system}'.")

    logger.info("Wi-Fi info: connected=%s ssid=%s", info.connected, info.ssid)
    return info
