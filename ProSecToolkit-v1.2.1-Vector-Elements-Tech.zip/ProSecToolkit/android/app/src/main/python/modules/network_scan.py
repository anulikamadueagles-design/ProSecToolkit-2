"""
modules/network_scan.py — Local network host discovery.

Discovers live hosts on a user-specified network range using ICMP ping
sweeps (cross-platform, via the system `ping` command) with an optional
ARP-based sweep when scapy is available and the process has sufficient
privileges. Intended for scanning networks the user owns/administers —
see AUTHORIZATION_NOTICE in config.py.
"""

from __future__ import annotations

import ipaddress
import logging
import platform
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass

from config import AppConfig
from core.utils import resolve_hostname


@dataclass
class HostResult:
    ip: str
    alive: bool
    hostname: str | None = None
    rtt_ms: float | None = None


def _ping_once(ip: str, timeout: float) -> tuple[bool, float | None]:
    """
    Ping a single host using the system ping utility.

    Returns:
        (alive, round_trip_ms) — rtt_ms is best-effort parsed and may be
        None even when alive is True if parsing the platform's ping
        output fails.
    """
    system = platform.system().lower()
    timeout_ms = max(int(timeout * 1000), 100)

    if system == "windows":
        cmd = ["ping", "-n", "1", "-w", str(timeout_ms), ip]
    else:
        # Linux, macOS, Android/Pydroid 3 (BusyBox ping accepts -c/-W)
        wait_sec = max(int(timeout), 1)
        cmd = ["ping", "-c", "1", "-W", str(wait_sec), ip]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout + 2
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False, None

    alive = result.returncode == 0
    rtt_ms = None
    if alive:
        for token in result.stdout.replace("=", " ").split():
            if "ms" in token:
                try:
                    rtt_ms = float(token.replace("ms", ""))
                    break
                except ValueError:
                    continue
    return alive, rtt_ms


def discover_hosts(
    network_cidr: str,
    config: AppConfig,
    logger: logging.Logger,
    resolve_names: bool = True,
    max_workers: int = 50,
) -> list[HostResult]:
    """
    Discover live hosts within a given CIDR range via ICMP ping sweep.

    Args:
        network_cidr: e.g. "192.168.1.0/24". Should be a network the
            user owns or is authorized to assess.
        config: Application configuration (uses scan.host_discovery_timeout).
        logger: Logger for diagnostic output.
        resolve_names: Whether to attempt reverse hostname resolution
            for each responsive host.
        max_workers: Thread pool size for concurrent pings.

    Returns:
        A list of HostResult for hosts that responded (alive == True).
    """
    try:
        network = ipaddress.ip_network(network_cidr, strict=False)
    except ValueError as exc:
        logger.error("Invalid network CIDR '%s': %s", network_cidr, exc)
        raise

    hosts = list(network.hosts()) or [network.network_address]
    logger.info("Starting host discovery on %s (%d addresses)", network_cidr, len(hosts))

    timeout = config.scan.host_discovery_timeout
    results: list[HostResult] = []

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_ping_once, str(ip), timeout): str(ip) for ip in hosts
        }
        for future in as_completed(futures):
            ip = futures[future]
            try:
                alive, rtt = future.result()
            except Exception as exc:  # noqa: BLE001
                logger.debug("Ping failed for %s: %s", ip, exc)
                continue
            if alive:
                hostname = resolve_hostname(ip) if resolve_names else None
                results.append(HostResult(ip=ip, alive=True, hostname=hostname, rtt_ms=rtt))

    results.sort(key=lambda h: tuple(int(p) for p in h.ip.split(".")) if h.ip.count(".") == 3 else (0,))
    logger.info("Host discovery complete: %d live hosts found", len(results))
    return results
