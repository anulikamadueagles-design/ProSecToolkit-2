"""Evidence-aware risk scoring."""
from __future__ import annotations
from dataclasses import dataclass, field
from modules.config_audit import AuditFinding
_WEIGHTS={"LOW":1,"MEDIUM":5,"HIGH":15,"CRITICAL":30}
@dataclass
class RiskAssessment:
    score:int
    level:str
    explanation:str
    severity_counts:dict[str,int]=field(default_factory=dict)
def calculate_risk(findings:list[AuditFinding])->RiskAssessment:
    counts={"LOW":0,"MEDIUM":0,"HIGH":0}
    score=0
    for f in findings:
        sev=f.severity.upper()
        if sev in counts: counts[sev]+=1
        if sev in _WEIGHTS and getattr(f,"status","OBSERVED") not in {"ERROR","NOT_TESTED","NOT_ESTABLISHED","NOT_APPLICABLE"} and not getattr(f,"positive_control",False):
            score+=_WEIGHTS[sev]
    level="HIGH" if score>=30 else "MEDIUM" if score>=10 else "LOW"
    explanation=(f"{counts['HIGH']} high-severity, {counts['MEDIUM']} medium-severity, and {counts['LOW']} low-severity finding(s) "
                 f"contributed to a total score of {score}, resulting in an overall {level} risk rating. "
                 "Informational, positive-control, error, and not-established findings do not increase the score.")
    return RiskAssessment(score,level,explanation,counts)
