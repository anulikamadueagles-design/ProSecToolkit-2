"""
modules/dns_tools.py — DNS lookup, reverse DNS, and basic latency checks.

Uses dnspython where available for richer record-type queries, falling
back to the standard library `socket` module for basic forward/reverse
resolution if dnspython is not installed.
"""

from __future__ import annotations

import logging
import socket
import time
from dataclasses import dataclass, field

from config import AppConfig

try:
    import dns.resolver
    _HAS_DNSPYTHON = True
except ImportError:  # pragma: no cover - dnspython is in requirements.txt
    _HAS_DNSPYTHON = False


@dataclass
class DNSResult:
    query: str
    record_type: str
    answers: list[str] = field(default_factory=list)
    error: str | None = None


@dataclass
class LatencyResult:
    host: str
    reachable: bool
    latency_ms: float | None = None
    error: str | None = None


def forward_lookup(
    hostname: str,
    config: AppConfig,
    logger: logging.Logger,
    record_types: tuple[str, ...] = ("A", "AAAA", "MX", "NS", "TXT"),
) -> list[DNSResult]:
    """
    Perform forward DNS lookups for the given hostname across common
    record types.
    """
    results: list[DNSResult] = []

    if _HAS_DNSPYTHON:
        resolver = dns.resolver.Resolver()
        resolver.timeout = config.scan.dns_timeout
        resolver.lifetime = config.scan.dns_timeout

        for rtype in record_types:
            try:
                answer = resolver.resolve(hostname, rtype)
                results.append(DNSResult(
                    query=hostname, record_type=rtype,
                    answers=[str(rdata) for rdata in answer],
                ))
            except dns.resolver.NoAnswer:
                results.append(DNSResult(query=hostname, record_type=rtype, answers=[]))
            except dns.resolver.NXDOMAIN:
                results.append(DNSResult(
                    query=hostname, record_type=rtype, error="NXDOMAIN (domain does not exist)"
                ))
                break
            except Exception as exc:  # noqa: BLE001
                logger.debug("DNS query failed for %s %s: %s", hostname, rtype, exc)
                results.append(DNSResult(query=hostname, record_type=rtype, error=str(exc)))
    else:
        # Minimal fallback: standard library only supports A/AAAA-style
        # resolution via getaddrinfo, not full record-type queries.
        logger.warning("dnspython not installed; falling back to basic A-record lookup only.")
        try:
            infos = socket.getaddrinfo(hostname, None)
            addrs = sorted({info[4][0] for info in infos})
            results.append(DNSResult(query=hostname, record_type="A/AAAA", answers=addrs))
        except socket.gaierror as exc:
            results.append(DNSResult(query=hostname, record_type="A/AAAA", error=str(exc)))

    return results


def reverse_lookup(ip: str, logger: logging.Logger) -> DNSResult:
    """Perform a reverse DNS (PTR) lookup for the given IP address."""
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
        return DNSResult(query=ip, record_type="PTR", answers=[hostname])
    except socket.herror as exc:
        logger.debug("Reverse lookup failed for %s: %s", ip, exc)
        return DNSResult(query=ip, record_type="PTR", error=str(exc))


def check_latency(host: str, config: AppConfig, logger: logging.Logger, port: int = 80) -> LatencyResult:
    """
    Measure basic TCP-connect latency to a host/port. Uses port 80 by
    default as a general reachability probe; callers may pass a more
    relevant port (e.g. 443 for HTTPS-only hosts).
    """
    timeout = config.scan.host_discovery_timeout
    start = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            elapsed_ms = (time.perf_counter() - start) * 1000
            return LatencyResult(host=host, reachable=True, latency_ms=round(elapsed_ms, 2))
    except (socket.timeout, OSError) as exc:
        logger.debug("Latency check failed for %s:%s: %s", host, port, exc)
        return LatencyResult(host=host, reachable=False, error=str(exc))
