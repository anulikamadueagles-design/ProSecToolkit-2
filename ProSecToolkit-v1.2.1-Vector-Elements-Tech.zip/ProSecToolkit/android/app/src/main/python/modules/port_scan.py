"""
modules/port_scan.py — Configurable TCP port scanning.

Performs a threaded TCP connect() scan against a single host over a
configurable port range or an explicit list of ports (e.g. config.scan
.common_ports). This is a "connect scan" only — no SYN/stealth scanning,
no packet crafting, and no service exploitation. Intended for inventorying
open services on systems the user owns/administers.
"""

from __future__ import annotations

import logging
import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass

from config import AppConfig

# Minimal, well-known service name mapping for common ports. Not
# exhaustive — used only to make report output more readable.
_COMMON_SERVICES = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 111: "RPCBind", 135: "MSRPC", 139: "NetBIOS",
    143: "IMAP", 443: "HTTPS", 445: "SMB", 993: "IMAPS", 995: "POP3S",
    1723: "PPTP", 3306: "MySQL", 3389: "RDP", 5900: "VNC",
    8080: "HTTP-Alt", 8443: "HTTPS-Alt",
}


@dataclass
class PortResult:
    port: int
    open: bool
    service: str | None = None
    banner: str | None = None


def _grab_banner(sock: socket.socket) -> str | None:
    """Best-effort banner grab; returns None on any failure or timeout."""
    try:
        sock.settimeout(0.75)
        data = sock.recv(128)
        return data.decode(errors="replace").strip() or None
    except (socket.timeout, OSError):
        return None


def _scan_port(host: str, port: int, timeout: float, grab_banners: bool) -> PortResult:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            if result == 0:
                banner = _grab_banner(sock) if grab_banners else None
                return PortResult(
                    port=port, open=True,
                    service=_COMMON_SERVICES.get(port), banner=banner,
                )
    except (socket.gaierror, OSError):
        pass
    return PortResult(port=port, open=False)


def scan_ports(
    host: str,
    config: AppConfig,
    logger: logging.Logger,
    ports: list[int] | None = None,
    grab_banners: bool = True,
) -> list[PortResult]:
    """
    Scan a host for open TCP ports.

    Args:
        host: Target hostname or IP (must be owned/authorized).
        config: Application configuration (uses scan.port_scan_* settings).
        logger: Logger for diagnostic output.
        ports: Explicit list of ports to scan. If None, uses the
            configured port_scan_start..port_scan_end range.
        grab_banners: Whether to attempt a short banner grab on open ports.

    Returns:
        List of PortResult for ports found OPEN (closed ports are omitted
        from the returned list but are counted in the log summary).
    """
    if ports is None:
        ports = list(range(config.scan.port_scan_start, config.scan.port_scan_end + 1))

    timeout = config.scan.port_scan_timeout
    max_workers = config.scan.port_scan_max_threads

    logger.info("Starting port scan on %s (%d ports, %d threads)", host, len(ports), max_workers)

    open_ports: list[PortResult] = []
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_scan_port, host, p, timeout, grab_banners): p for p in ports}
        for future in as_completed(futures):
            try:
                result = future.result()
            except Exception as exc:  # noqa: BLE001
                logger.debug("Port scan error for %s:%s: %s", host, futures[future], exc)
                continue
            if result.open:
                open_ports.append(result)

    open_ports.sort(key=lambda r: r.port)
    logger.info("Port scan complete on %s: %d open ports found", host, len(open_ports))
    return open_ports
