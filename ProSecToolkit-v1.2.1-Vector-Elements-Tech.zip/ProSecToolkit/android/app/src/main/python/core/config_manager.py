"""
core/config_manager.py — Load and persist user configuration overrides.

Reads `config.ini` (created on first run if absent) and merges values
into an AppConfig instance from config.py. This lets users persist
preferences (default port range, thread count, report formats, etc.)
without editing source code.
"""

from __future__ import annotations

import configparser
from dataclasses import asdict

from config import AppConfig, CONFIG_FILE


def _write_defaults(config: AppConfig) -> None:
    """Write an AppConfig instance out to config.ini in INI format."""
    parser = configparser.ConfigParser()

    parser["scan"] = {k: str(v) for k, v in asdict(config.scan).items()}
    parser["report"] = {k: str(v) for k, v in asdict(config.report).items()}
    parser["general"] = {
        "log_level": config.log_level,
        "color_output": str(config.color_output),
    }

    with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
        parser.write(fh)


def load_config(default: AppConfig) -> AppConfig:
    """
    Load configuration from config.ini, creating it from defaults if it
    does not yet exist. Values present in the file override the passed
    default AppConfig; missing values fall back to defaults.

    Args:
        default: The baseline AppConfig (see config.DEFAULT_CONFIG).

    Returns:
        An AppConfig reflecting any user overrides found in config.ini.
    """
    if not CONFIG_FILE.exists():
        _write_defaults(default)
        return default

    parser = configparser.ConfigParser()
    parser.read(CONFIG_FILE, encoding="utf-8")

    config = default

    if parser.has_section("scan"):
        s = parser["scan"]
        config.scan.port_scan_start = s.getint("port_scan_start", config.scan.port_scan_start)
        config.scan.port_scan_end = s.getint("port_scan_end", config.scan.port_scan_end)
        config.scan.port_scan_timeout = s.getfloat("port_scan_timeout", config.scan.port_scan_timeout)
        config.scan.port_scan_max_threads = s.getint(
            "port_scan_max_threads", config.scan.port_scan_max_threads
        )
        config.scan.host_discovery_timeout = s.getfloat(
            "host_discovery_timeout", config.scan.host_discovery_timeout
        )
        config.scan.dns_timeout = s.getfloat("dns_timeout", config.scan.dns_timeout)
        config.scan.http_timeout = s.getfloat("http_timeout", config.scan.http_timeout)
        config.scan.tls_timeout = s.getfloat("tls_timeout", config.scan.tls_timeout)

    if parser.has_section("report"):
        r = parser["report"]
        config.report.company_name = r.get("company_name", config.report.company_name)
        config.report.assessor_name = r.get("assessor_name", config.report.assessor_name)

    if parser.has_section("general"):
        g = parser["general"]
        config.log_level = g.get("log_level", config.log_level)
        config.color_output = g.getboolean("color_output", config.color_output)

    return config


def save_config(config: AppConfig) -> None:
    """Persist the current AppConfig to config.ini."""
    _write_defaults(config)
