"""
core/logger.py — Structured, timestamped logging for ProSecToolkit.

All modules should obtain a logger via `get_logger(__name__)` rather than
using print() for diagnostic, warning, or error output. User-facing CLI
output (menus, results) still uses print()/Colors, but anything useful
for debugging or auditing goes through this logger.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path

from config import LOGS_DIR

_LOG_FILE_TEMPLATE = "prosectoolkit_{date}.log"
_CONFIGURED = False


def _configure_root(log_level: str = "INFO") -> None:
    """Configure the root logging setup exactly once per process."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    log_file: Path = LOGS_DIR / _LOG_FILE_TEMPLATE.format(
        date=datetime.now().strftime("%Y%m%d")
    )

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(formatter)

    # Console handler only shows warnings and above by default; the CLI's
    # own print()/Colors output already communicates normal progress.
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.WARNING)

    root = logging.getLogger()
    root.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    root.addHandler(file_handler)
    root.addHandler(console_handler)

    _CONFIGURED = True


def get_logger(name: str, log_level: str = "INFO") -> logging.Logger:
    """
    Return a configured logger for the given module name.

    Args:
        name: Typically `__name__` of the calling module.
        log_level: Root log level to apply on first configuration.

    Returns:
        A standard library Logger instance writing to logs/ and stderr.
    """
    _configure_root(log_level)
    return logging.getLogger(name)
