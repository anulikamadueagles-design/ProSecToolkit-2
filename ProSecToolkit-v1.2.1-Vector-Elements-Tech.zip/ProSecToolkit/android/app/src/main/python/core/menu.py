"""
core/menu.py — Interactive CLI menu system for ProSecToolkit.

Defines MainMenu, which drives the top-level interactive loop, plus
submenus for network tools, web analysis, system info, full assessments,
and reporting. Module imports are deferred to handler methods to keep
startup fast and to isolate any single module's optional-dependency
issues from the rest of the toolkit.
"""

from __future__ import annotations

import logging
from datetime import datetime

from config import AppConfig, APP_NAME, APP_VERSION
from core.colors import Colors
from core.utils import is_valid_cidr, is_private_network

try:
    from tabulate import tabulate
    _HAS_TABULATE = True
except ImportError:  # pragma: no cover
    _HAS_TABULATE = False


def _table(rows: list[list], headers: list[str]) -> str:
    """Render a table using tabulate if available, else a simple fallback."""
    if _HAS_TABULATE:
        return tabulate(rows, headers=headers, tablefmt="simple")
    # Minimal fallback: fixed-width columns.
    out = [" | ".join(headers), "-" * 60]
    for row in rows:
        out.append(" | ".join(str(c) for c in row))
    return "\n".join(out)


class MainMenu:
    @staticmethod
    def _is_cancel(value: str) -> bool:
        return value.strip().lower() in {"0", "back", "cancel", "q", "quit"}

    """Top-level interactive menu loop for ProSecToolkit."""

    def __init__(self, config: AppConfig, logger: logging.Logger) -> None:
        self.config = config
        self.logger = logger
        self._running = True

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------
    def run(self) -> None:
        """Run the main menu loop until the user chooses to exit."""
        while self._running:
            self._print_main_menu()
            choice = self._prompt("Select an option: ")

            handlers = {
                "1": self._handle_network_menu,
                "2": self._handle_web_menu,
                "3": self._handle_system_info,
                "4": self._handle_full_assessment,
                "5": self._handle_reports_menu,
                "6": self._handle_settings,
                "7": self._handle_banking_simulator,
                "0": self._handle_exit,
            }

            handler = handlers.get(choice)
            if handler is None:
                print(f"{Colors.RED}Invalid option.{Colors.RESET}\n")
                continue

            try:
                handler()
            except Exception as exc:  # noqa: BLE001
                self.logger.exception("Error handling menu option %s", choice)
                print(f"{Colors.RED}An error occurred: {exc}{Colors.RESET}\n")

    # ------------------------------------------------------------------
    # Display / input helpers
    # ------------------------------------------------------------------
    def _print_main_menu(self) -> None:
        print(f"\n{Colors.BOLD}{Colors.CYAN}=== {APP_NAME} v{APP_VERSION} — Main Menu ==={Colors.RESET}")
        print("1. Network Tools (discovery, port scan, DNS, Wi-Fi)")
        print("2. Web Analysis (HTTP, headers, TLS, certificate)")
        print("3. System Information")
        print("4. Run Full Assessment (all modules + report)")
        print("5. Reports (view history)")
        print("6. Settings")
        print("7. Banking Simulator (test accounts only — no real money)")
        print("0. Exit")

    @staticmethod
    def _prompt(message: str) -> str:
        try:
            value = input(f"{Colors.GREEN}{message}{Colors.RESET}").strip()
        except (EOFError, KeyboardInterrupt):
            return "0"
        # Protect against Android paste workflows that accidentally paste the
        # visible prompt back into the input field.
        prefix = message.strip()
        while prefix and value.startswith(prefix):
            value = value[len(prefix):].strip()
        return value

    def _warn_if_not_private(self, target: str) -> None:
        """Soft reminder (not a hard block) to keep scans in-scope."""
        if is_valid_cidr(target) and not is_private_network(target):
            print(f"{Colors.YELLOW}Note: {target} is not a private/local network range. "
                  f"Make sure you are authorized to assess it.{Colors.RESET}")

    # ------------------------------------------------------------------
    # 1. Network Tools
    # ------------------------------------------------------------------
    def _handle_network_menu(self) -> None:
        print(f"\n{Colors.BOLD}-- Network Tools --{Colors.RESET}")
        print("1. Discover hosts on a network (CIDR)")
        print("2. Port scan a host")
        print("3. DNS lookup")
        print("4. Reverse DNS lookup")
        print("5. Latency check")
        print("6. Scan nearby Wi-Fi networks")
        print("7. Connect to an authorized Wi-Fi network")
        print("0. Back")
        choice = self._prompt("Select an option: ")

        if choice == "1":
            self._run_host_discovery()
        elif choice == "2":
            self._run_port_scan()
        elif choice == "3":
            self._run_dns_lookup()
        elif choice == "4":
            self._run_reverse_dns()
        elif choice == "5":
            self._run_latency_check()
        elif choice == "6":
            self._run_wifi_scan()
        elif choice == "7":
            self._run_wifi_connect()

    def _run_host_discovery(self) -> None:
        from modules.network_scan import discover_hosts

        cidr = self._prompt("Network CIDR to scan (e.g. 192.168.1.0/24): ")
        if not is_valid_cidr(cidr):
            print(f"{Colors.RED}Invalid CIDR.{Colors.RESET}")
            return
        self._warn_if_not_private(cidr)

        print(f"{Colors.CYAN}Discovering hosts on {cidr}...{Colors.RESET}")
        hosts = discover_hosts(cidr, self.config, self.logger)
        if not hosts:
            print(f"{Colors.YELLOW}No live hosts found.{Colors.RESET}")
            return
        rows = [[h.ip, h.hostname or "-", f"{h.rtt_ms} ms" if h.rtt_ms else "-"] for h in hosts]
        print(_table(rows, ["IP", "Hostname", "RTT"]))

    def _run_port_scan(self) -> None:
        from modules.port_scan import scan_ports

        host = self._prompt("Target host/IP: ")
        if not host:
            return
        use_common = self._prompt("Scan common ports only? (y/n): ").lower() == "y"
        ports = list(self.config.scan.common_ports) if use_common else None

        print(f"{Colors.CYAN}Scanning {host}...{Colors.RESET}")
        results = scan_ports(host, self.config, self.logger, ports=ports)
        if not results:
            print(f"{Colors.YELLOW}No open ports found.{Colors.RESET}")
            return
        rows = [[r.port, r.service or "-", r.banner or "-"] for r in results]
        print(_table(rows, ["Port", "Service", "Banner"]))

    def _run_dns_lookup(self) -> None:
        from modules.dns_tools import forward_lookup

        hostname = self._prompt("Hostname to look up: ")
        if not hostname:
            return
        results = forward_lookup(hostname, self.config, self.logger)
        rows = [[r.record_type, ", ".join(r.answers) if r.answers else (r.error or "-")] for r in results]
        print(_table(rows, ["Type", "Answer"]))

    def _run_reverse_dns(self) -> None:
        from modules.dns_tools import reverse_lookup

        ip = self._prompt("IP address to reverse lookup: ")
        if not ip:
            return
        result = reverse_lookup(ip, self.logger)
        if result.error:
            print(f"{Colors.YELLOW}{result.error}{Colors.RESET}")
        else:
            print(f"{Colors.GREEN}{ip} -> {result.answers[0]}{Colors.RESET}")

    def _run_wifi_scan(self) -> None:
        from modules.wifi_manager import scan_wifi
        print(f"{Colors.CYAN}Scanning nearby Wi-Fi networks...{Colors.RESET}")
        networks, error = scan_wifi(self.logger)
        if error:
            print(f"{Colors.YELLOW}{error}{Colors.RESET}")
            return
        rows = [[n.ssid, n.signal_percent if n.signal_percent is not None else "-", n.security or "-", "YES" if n.connected else "NO"] for n in networks]
        print(_table(rows, ["SSID", "Signal %", "Security", "Connected"]))

    def _run_wifi_connect(self) -> None:
        from modules.wifi_manager import connect_authorized_wifi
        ssid = self._prompt("Authorized Wi-Fi SSID: ")
        if not ssid:
            return
        security = self._prompt("Security (WPA2/WPA3/Open): ") or "WPA2"
        password = "" if security.lower() == "open" else self._prompt("Wi-Fi password: ")
        result = connect_authorized_wifi(ssid, password, security, self.logger)
        color = Colors.GREEN if result.success else Colors.RED
        print(f"{color}{result.message}{Colors.RESET}")

    def _run_latency_check(self) -> None:
        from modules.dns_tools import check_latency

        host = self._prompt("Host to check: ")
        if not host:
            return
        result = check_latency(host, self.config, self.logger)
        if result.reachable:
            print(f"{Colors.GREEN}{host} reachable — {result.latency_ms} ms{Colors.RESET}")
        else:
            print(f"{Colors.RED}{host} unreachable: {result.error}{Colors.RESET}")

    # ------------------------------------------------------------------
    # 2. Web Analysis
    # ------------------------------------------------------------------
    def _handle_web_menu(self) -> None:
        print(f"\n{Colors.BOLD}-- Web Analysis --{Colors.RESET}")
        print("1. HTTP response analysis")
        print("2. Security header check")
        print("3. TLS configuration check")
        print("4. Certificate check")
        print("0. Back")
        choice = self._prompt("Select an option: ")

        if choice == "1":
            self._run_http_analysis()
        elif choice == "2":
            self._run_header_check()
        elif choice == "3":
            self._run_tls_check()
        elif choice == "4":
            self._run_cert_check()

    def _run_http_analysis(self) -> None:
        from modules.http_analyzer import analyze_url

        url = self._prompt("URL to analyze (e.g. https://example.com): ")
        if not url:
            return
        result = analyze_url(url, self.config, self.logger)
        if result.error:
            print(f"{Colors.RED}{result.error}{Colors.RESET}")
            return
        print(f"Status: {result.status_code}   Final URL: {result.final_url}")
        print(f"Server: {result.server_banner or 'unknown'}   Elapsed: {result.elapsed_ms} ms")
        if result.redirect_chain:
            print("Redirects:")
            for hop in result.redirect_chain:
                print(f"  {hop.status_code} -> {hop.url}")

    def _run_header_check(self) -> None:
        from modules.http_analyzer import analyze_url
        from modules.security_headers import evaluate_headers

        url = self._prompt("URL to check headers for: ")
        if not url:
            return
        result = analyze_url(url, self.config, self.logger)
        if result.error:
            print(f"{Colors.RED}{result.error}{Colors.RESET}")
            return
        findings = evaluate_headers(result.headers)
        rows = [
            [f.header, "present" if f.present else "MISSING", f.value or "-"]
            for f in findings
        ]
        print(_table(rows, ["Header", "Status", "Value"]))

    def _run_tls_check(self) -> None:
        from modules.tls_analyzer import analyze_tls

        host = self._prompt("Host to check TLS on: ")
        if not host:
            return
        result = analyze_tls(host, self.config, self.logger)
        if result.error:
            print(f"{Colors.RED}{result.error}{Colors.RESET}")
            return
        print(f"Protocol: {result.protocol}   Cipher: {result.cipher_name} ({result.cipher_bits}-bit)")
        for f in result.findings:
            print(f"  {Colors.risk(f.severity)}[{f.severity}]{Colors.RESET} {f.description}")

    def _run_cert_check(self) -> None:
        from modules.certificate_check import check_certificate

        host = self._prompt("Host to check certificate on: ")
        if not host:
            return
        cert = check_certificate(host, self.config, self.logger)
        if cert.error:
            print(f"{Colors.RED}{cert.error}{Colors.RESET}")
            return
        print(f"Subject: {cert.subject}")
        print(f"Issuer:  {cert.issuer}")
        print(f"Valid:   {cert.not_before} -> {cert.not_after}")
        print(f"Status:  {Colors.risk(cert.status.upper() if cert.status else 'LOW')}"
              f"{cert.status} ({cert.days_until_expiry} days remaining){Colors.RESET}")

    # ------------------------------------------------------------------
    # 3. System Information
    # ------------------------------------------------------------------
    def _handle_system_info(self) -> None:
        from modules.system_info import gather_system_info
        from modules.wifi_info import get_wifi_info

        info = gather_system_info(self.logger)
        print(f"\n{Colors.BOLD}-- System Information --{Colors.RESET}")
        print(f"Hostname: {info.hostname}")
        print(f"OS:       {info.os_name} {info.os_release} ({info.architecture})")
        print(f"Python:   {info.python_version}")
        print(f"Local IPs: {', '.join(info.local_ips) or '-'}")

        rows = [[i.name, ", ".join(i.addresses) or "-", i.is_up] for i in info.interfaces]
        print(_table(rows, ["Interface", "Addresses", "Up"]))

        wifi = get_wifi_info(self.logger)
        print(f"\n{Colors.BOLD}Wi-Fi:{Colors.RESET} ", end="")
        if wifi.connected:
            print(f"SSID={wifi.ssid}  Signal={wifi.signal_percent}%  Security={wifi.security}")
        else:
            print(f"{wifi.error}")

    # ------------------------------------------------------------------
    # 4. Full Assessment
    # ------------------------------------------------------------------
    def _handle_full_assessment(self) -> None:
        from modules.port_scan import scan_ports
        from modules.http_analyzer import analyze_url
        from modules.security_headers import evaluate_headers
        from modules.tls_analyzer import analyze_tls
        from modules.certificate_check import check_certificate
        from modules.config_audit import run_full_audit, AuditFinding
        from modules.risk_score import calculate_risk
        from modules.coverage import get_coverage_findings
        from modules.report_generator import build_context, generate_reports
        from core.database import record_assessment

        target = self._prompt("Target hostname (e.g. example.com): ")
        if not target:
            return
        self._warn_if_not_private(target)
        started_at = datetime.now().isoformat()

        print(f"{Colors.CYAN}Running full assessment against {target}...{Colors.RESET}")

        print("  [1/4] Port scanning common ports...")
        open_ports = scan_ports(target, self.config, self.logger, ports=list(self.config.scan.common_ports))

        print("  [2/4] Analyzing HTTP/HTTPS...")
        http_result = analyze_url(f"https://{target}", self.config, self.logger)
        header_findings = evaluate_headers(http_result.headers) if not http_result.error else []

        print("  [3/4] Checking TLS configuration and certificate...")
        tls_result = analyze_tls(target, self.config, self.logger)
        cert_result = check_certificate(target, self.config, self.logger)

        print("  [4/4] Scoring risk and generating report...")
        findings = run_full_audit(
            open_ports=open_ports,
            header_findings=header_findings,
            tls_findings=tls_result.findings if not tls_result.error else [],
            certificate=cert_result,
        )
        if http_result.error:
            findings.append(AuditFinding("HTTP Analysis", f"HTTP analysis could not complete: {http_result.error}", "INFO", "Retry when the target is reachable.", "ERROR", http_result.error))
        if tls_result.error:
            findings.append(AuditFinding("TLS Analysis", f"TLS analysis could not complete: {tls_result.error}", "INFO", "Retry TLS analysis when the target is reachable.", "ERROR", tls_result.error))
        for item in get_coverage_findings():
            findings.append(AuditFinding(item["category"], item["description"], "INFO", item["recommendation"], item["status"]))
        risk = calculate_risk(findings)
        ctx = build_context(target, self.config, findings, risk)
        report_paths = generate_reports(ctx, self.config, self.logger)

        record_assessment(
            target=target,
            started_at=started_at,
            finished_at=datetime.now().isoformat(),
            risk_level=risk.level,
            risk_score=risk.score,
            findings={"count": len(findings)},
            report_path=str(report_paths.get("txt")),
        )

        print(f"\n{Colors.BOLD}Overall Risk: {Colors.risk(risk.level)}{risk.level}{Colors.RESET} "
              f"(score: {risk.score})")
        print(risk.explanation)
        print("\nReports generated:")
        for fmt, path in report_paths.items():
            print(f"  {fmt.upper()}: {path if path else '(skipped — dependency not installed)'}")

    # ------------------------------------------------------------------
    # 5. Reports (history)
    # ------------------------------------------------------------------
    def _handle_reports_menu(self) -> None:
        from core.database import list_assessments

        records = list_assessments()
        if not records:
            print(f"{Colors.YELLOW}No assessments recorded yet. Run option 4 first.{Colors.RESET}")
            return
        rows = [
            [r["id"], r["target"], r["started_at"], r["risk_level"], r["risk_score"], r["report_path"]]
            for r in records
        ]
        print(_table(rows, ["ID", "Target", "Started", "Risk", "Score", "Report Path"]))

    # ------------------------------------------------------------------
    # 6. Settings
    # ------------------------------------------------------------------
    def _handle_settings(self) -> None:
        from core.config_manager import save_config

        print(f"\n{Colors.BOLD}-- Settings --{Colors.RESET}")
        print(f"1. Assessor name (current: {self.config.report.assessor_name})")
        print(f"2. Company/organization (current: {self.config.report.company_name})")
        print(f"3. Port scan range (current: {self.config.scan.port_scan_start}-{self.config.scan.port_scan_end})")
        print("0. Back")
        choice = self._prompt("Select a setting to change: ")

        if choice == "1":
            self.config.report.assessor_name = self._prompt("New assessor name: ") or self.config.report.assessor_name
        elif choice == "2":
            self.config.report.company_name = self._prompt("New company name: ") or self.config.report.company_name
        elif choice == "3":
            try:
                start = int(self._prompt("Start port: "))
                end = int(self._prompt("End port: "))
                if 0 < start <= end <= 65535:
                    self.config.scan.port_scan_start = start
                    self.config.scan.port_scan_end = end
                else:
                    print(f"{Colors.RED}Invalid range.{Colors.RESET}")
                    return
            except ValueError:
                print(f"{Colors.RED}Ports must be integers.{Colors.RESET}")
                return
        else:
            return

        save_config(self.config)
        print(f"{Colors.GREEN}Settings saved.{Colors.RESET}")

    # ------------------------------------------------------------------
    # 7. Banking simulator
    # ------------------------------------------------------------------
    def _handle_banking_simulator(self) -> None:
        from modules.banking_simulator import create_account, get_account, transfer, list_transactions
        print(f"\n{Colors.BOLD}-- Banking Simulator --{Colors.RESET}")
        print(f"{Colors.YELLOW}SIMULATION ONLY — NO REAL BANK OR REAL MONEY IS USED.{Colors.RESET}")
        print("1. Create test account")
        print("2. Check test balance")
        print("3. Transfer simulated funds")
        print("4. Transaction history")
        print("0. Back")
        choice=self._prompt("Select an option: ")
        try:
            if choice == "1":
                acc=self._prompt("Test account number: "); owner=self._prompt("Owner name: "); bal=int(self._prompt("Starting balance (whole units): ")); pin=self._prompt("Authorization PIN: ")
                create_account(acc,owner,bal,pin); print(f"{Colors.GREEN}Test account created.{Colors.RESET}")
            elif choice == "2":
                acc=self._prompt("Test account number: "); pin=self._prompt("Authorization PIN: "); a=get_account(acc,pin); print(f"Owner: {a.owner}\nBalance: {a.balance}")
            elif choice == "3":
                sender=self._prompt("Sender test account: "); recipient=self._prompt("Recipient test account: "); amount=int(self._prompt("Amount: ")); pin=self._prompt("Authorization PIN: "); r=transfer(sender,recipient,amount,pin); print(f"Status: {'SUCCESS' if r.success else 'FAILED'}\n{r.message}"); print(f"Transaction ID: {r.transaction_id}");
                if r.balance is not None: print(f"New sender balance: {r.balance}")
            elif choice == "4":
                rows=[[r[0],r[1],r[2],r[3],r[5]] for r in list_transactions()]; print(_table(rows,["Transaction","Sender","Recipient","Amount","Status"]))
        except (ValueError, PermissionError) as exc:
            print(f"{Colors.RED}{exc}{Colors.RESET}")

    # ------------------------------------------------------------------
    # 0. Exit
    # ------------------------------------------------------------------
    def _handle_exit(self) -> None:
        print(f"{Colors.CYAN}Goodbye.{Colors.RESET}")
        self._running = False
