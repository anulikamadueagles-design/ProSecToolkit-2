"""core/colors.py — Cross-platform ANSI color helpers for CLI output."""

from __future__ import annotations

try:
    import colorama
    colorama.init(autoreset=False)
except ImportError:  # pragma: no cover - colorama is in requirements.txt
    pass


class Colors:
    """ANSI color/style codes used throughout the CLI."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    @staticmethod
    def risk(level: str) -> str:
        """Return the color code appropriate for a risk level string."""
        mapping = {
            "LOW": Colors.GREEN,
            "MEDIUM": Colors.YELLOW,
            "HIGH": Colors.RED,
        }
        return mapping.get(level.upper(), Colors.WHITE)
