"""core/utils.py — Small shared helper functions used across modules."""

from __future__ import annotations

import ipaddress
import socket
from datetime import datetime


def timestamp() -> str:
    """Return a filesystem-safe current timestamp string."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def is_valid_ip(value: str) -> bool:
    """Return True if `value` is a syntactically valid IPv4/IPv6 address."""
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def is_valid_cidr(value: str) -> bool:
    """Return True if `value` is a syntactically valid CIDR network."""
    try:
        ipaddress.ip_network(value, strict=False)
        return True
    except ValueError:
        return False


def resolve_hostname(host: str) -> str | None:
    """Resolve a hostname to an IP address, or None on failure."""
    try:
        return socket.gethostbyname(host)
    except socket.gaierror:
        return None


def is_private_network(value: str) -> bool:
    """
    Return True if the given IP/CIDR falls within a private (RFC 1918/4193)
    or loopback range. Used as a soft guardrail to nudge users toward
    scanning networks they plausibly own, though it is not a substitute
    for the explicit authorization confirmation in main.py.
    """
    try:
        net = ipaddress.ip_network(value, strict=False)
        return net.is_private or net.is_loopback
    except ValueError:
        return False


def format_bytes(num: float) -> str:
    """Human-readable byte size formatting."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(num) < 1024.0:
            return f"{num:3.1f} {unit}"
        num /= 1024.0
    return f"{num:.1f} PB"


def truncate(text: str, max_len: int = 80) -> str:
    """Truncate text to max_len characters, appending an ellipsis."""
    return text if len(text) <= max_len else text[: max_len - 1] + "…"
