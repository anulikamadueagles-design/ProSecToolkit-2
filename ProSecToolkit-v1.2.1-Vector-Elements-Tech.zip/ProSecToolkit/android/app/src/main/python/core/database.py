"""
core/database.py — Lightweight SQLite persistence for scan/assessment history.

Stores a record of each assessment run (target, timestamp, findings
summary, risk score) so users can review history and reference past
reports. Uses only the standard library `sqlite3` module — no external
dependency required.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from config import BASE_DIR

DB_PATH: Path = BASE_DIR / "prosectoolkit.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    target TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    risk_level TEXT,
    risk_score INTEGER,
    findings_json TEXT,
    report_path TEXT
);
"""


@contextmanager
def _connect() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    """Create the database and schema if they do not already exist."""
    with _connect() as conn:
        conn.execute(_SCHEMA)


def record_assessment(
    target: str,
    started_at: str,
    finished_at: str | None,
    risk_level: str | None,
    risk_score: int | None,
    findings: dict[str, Any],
    report_path: str | None,
) -> int:
    """
    Insert a new assessment record.

    Returns:
        The new row's integer id.
    """
    init_db()
    with _connect() as conn:
        cur = conn.execute(
            """
            INSERT INTO assessments
                (target, started_at, finished_at, risk_level, risk_score,
                 findings_json, report_path)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                target,
                started_at,
                finished_at,
                risk_level,
                risk_score,
                json.dumps(findings),
                report_path,
            ),
        )
        return int(cur.lastrowid)


def list_assessments(limit: int = 20) -> list[sqlite3.Row]:
    """Return the most recent assessments, newest first."""
    init_db()
    with _connect() as conn:
        cur = conn.execute(
            "SELECT * FROM assessments ORDER BY id DESC LIMIT ?", (limit,)
        )
        return cur.fetchall()


def get_assessment(assessment_id: int) -> sqlite3.Row | None:
    """Fetch a single assessment record by id."""
    init_db()
    with _connect() as conn:
        cur = conn.execute(
            "SELECT * FROM assessments WHERE id = ?", (assessment_id,)
        )
        return cur.fetchone()
