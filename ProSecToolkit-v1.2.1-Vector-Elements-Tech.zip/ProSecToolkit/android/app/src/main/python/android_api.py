from config import AppConfig
import logging


def _cfg_logger():
    cfg = AppConfig()
    logger = logging.getLogger("ProSecToolkit.Android")
    if not logger.handlers:
        logger.addHandler(logging.NullHandler())
    logger.setLevel(logging.INFO)
    return cfg, logger


def _plain(obj):
    if hasattr(obj, "__dict__"):
        return {k: _plain(v) for k, v in obj.__dict__.items()}
    if isinstance(obj, (list, tuple)):
        return [_plain(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): _plain(v) for k, v in obj.items()}
    return obj


def headers(target):
    from modules.http_analyzer import analyze_url
    from modules.security_headers import analyze_headers
    cfg, logger = _cfg_logger()
    result = analyze_url(target, cfg, logger)
    if result.error:
        return _plain(result)
    return _plain(analyze_headers(result.headers, result.url))


def http(target):
    from modules.http_analyzer import analyze_url
    cfg, logger = _cfg_logger()
    return _plain(analyze_url(target, cfg, logger))


def tls(target):
    from modules.tls_analyzer import analyze_tls
    cfg, logger = _cfg_logger()
    host = target.replace("https://", "").replace("http://", "").split("/", 1)[0]
    return _plain(analyze_tls(host, cfg, logger))


def cert(target):
    from modules.certificate_check import check_certificate
    cfg, logger = _cfg_logger()
    host = target.replace("https://", "").replace("http://", "").split("/", 1)[0]
    return _plain(check_certificate(host, cfg, logger))


def dns(target):
    from modules.dns_tools import forward_lookup
    cfg, logger = _cfg_logger()
    return _plain(forward_lookup(target, cfg, logger))


def ports(target):
    from modules.port_scan import scan_ports
    cfg, logger = _cfg_logger()
    host = target.replace("https://", "").replace("http://", "").split("/", 1)[0]
    return _plain(scan_ports(host, cfg, logger, ports=list(cfg.scan.common_ports)))
