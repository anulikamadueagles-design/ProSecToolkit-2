"""
config.py
=========
Central configuration for ProSecToolkit.

This module defines default settings, path constants, and a lightweight
dataclass-based configuration object used throughout the application.
User-editable overrides are loaded from `config.ini` (managed by
`core/config_manager.py`) at runtime; the values here act as safe defaults.

IMPORTANT: ProSecToolkit is intended ONLY for defensive security
assessments performed on systems and networks the user owns or is
explicitly authorized to test. See README.md for the full usage policy.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import platform


# --------------------------------------------------------------------------
# Path constants
# --------------------------------------------------------------------------
BASE_DIR: Path = Path(__file__).resolve().parent
REPORTS_DIR: Path = BASE_DIR / "reports"
LOGS_DIR: Path = BASE_DIR / "logs"
ASSETS_DIR: Path = BASE_DIR / "assets"
CONFIG_FILE: Path = BASE_DIR / "config.ini"

# Ensure runtime directories exist on first import.
for _dir in (REPORTS_DIR, LOGS_DIR, ASSETS_DIR):
    _dir.mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------
# Application metadata
# --------------------------------------------------------------------------
APP_NAME: str = "ProSecToolkit"
APP_VERSION: str = "1.1.0"
APP_TAGLINE: str = "Defensive Security Assessment Toolkit"

# Detected once at import time; used by modules that need OS-aware behavior
# (e.g., Windows vs. Linux vs. Android/Pydroid socket permissions).
CURRENT_PLATFORM: str = platform.system()  # 'Windows', 'Linux', 'Darwin', ...
IS_PYDROID: bool = "ANDROID_ROOT" in __import__("os").environ


# --------------------------------------------------------------------------
# Legal / usage policy banner
# --------------------------------------------------------------------------
AUTHORIZATION_NOTICE: str = (
    "ProSecToolkit must only be used against systems, networks, and "
    "applications that you own or for which you have explicit, documented "
    "authorization to test. Unauthorized scanning or assessment of "
    "third-party systems may be illegal in your jurisdiction. By "
    "continuing, you confirm you have the right to assess the target(s) "
    "you specify."
)


# --------------------------------------------------------------------------
# Default scan / assessment settings
# --------------------------------------------------------------------------
@dataclass
class ScanDefaults:
    """Default parameters for network and port scanning modules."""

    port_scan_start: int = 1
    port_scan_end: int = 1024
    port_scan_timeout: float = 0.5          # seconds per port
    port_scan_max_threads: int = 100
    host_discovery_timeout: float = 1.0     # seconds per host (ping/ARP)
    dns_timeout: float = 3.0
    http_timeout: float = 5.0
    tls_timeout: float = 5.0
    common_ports: tuple[int, ...] = field(
        default_factory=lambda: (
            21, 22, 23, 25, 53, 80, 110, 111, 135, 139, 143, 443,
            445, 993, 995, 1723, 3306, 3389, 5900, 8080, 8443,
        )
    )


@dataclass
class ReportDefaults:
    """Default parameters for report generation."""

    company_name: str = "N/A"
    assessor_name: str = "N/A"
    output_formats: tuple[str, ...] = ("txt", "html", "pdf")
    include_executive_summary: bool = True
    include_remediation: bool = True


@dataclass
class AppConfig:
    """Top-level configuration object passed around the application."""

    scan: ScanDefaults = field(default_factory=ScanDefaults)
    report: ReportDefaults = field(default_factory=ReportDefaults)
    log_level: str = "INFO"
    color_output: bool = True


# A single shared default instance. `core/config_manager.py` may return a
# modified copy of this after reading config.ini / user overrides.
DEFAULT_CONFIG = AppConfig()
