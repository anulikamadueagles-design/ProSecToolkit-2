package com.vectorselementtech.prosectoolkit;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.app.Activity;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.util.List;

public class MainActivity extends Activity {
    private TextView status;
    private EditText target;
    private CheckBox auth;
    private Python py;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(com.vectorselementtech.prosectoolkit.R.layout.activity_main);
        status = findViewById(R.id.statusText);
        target = findViewById(R.id.targetInput);
        auth = findViewById(R.id.authCheck);
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
        py = Python.getInstance();

        bind(R.id.headersButton, "headers");
        bind(R.id.httpButton, "http");
        bind(R.id.tlsButton, "tls");
        bind(R.id.certButton, "cert");
        bind(R.id.dnsButton, "dns");
        bind(R.id.portButton, "ports");
        Button wifi = findViewById(R.id.wifiButton);
        wifi.setOnClickListener(v -> scanWifi());
    }

    private void bind(int id, String fn) {
        Button b = findViewById(id);
        b.setOnClickListener(v -> runPython(fn));
    }

    private void runPython(String fn) {
        if (!auth.isChecked()) { status.setText("Authorization confirmation is required."); return; }
        String t = target.getText().toString().trim();
        if (t.isEmpty()) { status.setText("Enter a target first."); return; }
        status.setText("Running " + fn + "…");
        new Thread(() -> {
            try {
                PyObject api = py.getModule("android_api");
                PyObject result = api.callAttr(fn, t);
                runOnUiThread(() -> status.setText(result.toString()));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Error: " + e.getMessage()));
            }
        }).start();
    }

    private void scanWifi() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
            return;
        }
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        if (wm == null) { status.setText("Wi-Fi service unavailable."); return; }
        try {
            wm.startScan();
            List<ScanResult> results = wm.getScanResults();
            StringBuilder out = new StringBuilder("Nearby Wi-Fi:\n");
            for (ScanResult r : results) out.append(r.SSID).append("  ").append(r.level).append(" dBm\n");
            status.setText(out.toString());
        } catch (SecurityException e) { status.setText("Wi-Fi permission required: " + e.getMessage()); }
    }
}
