# ProSecToolkit Privacy Policy — Template

Developer: David Kamsi Elvis
Brand: Vectors Element Tech

Replace this template with a final legal privacy policy and public HTTPS URL before publishing.

The application is a defensive security assessment toolkit. Collect only data required for requested features. Do not store banking passwords, PINs, OTPs, or secret API credentials. Any future banking integration must use an official provider authorization flow and disclose data processing and retention.

Support: ADD A REAL SUPPORT EMAIL BEFORE PUBLISHING
