# Android Wi-Fi support in v1.1.1

## Pydroid / Android 10

The CLI cannot use `nmcli` because Android does not ship NetworkManager.
Therefore v1.1.1 detects Android and reports that limitation instead of
producing a misleading scan failure.

For true Android Wi-Fi scanning/connection, build the Android front end with
the native Android Wi-Fi APIs. The Android component should request the
permissions required by the target Android SDK and should only connect using
credentials supplied by an authorized operator.

## Linux

On a Linux machine with NetworkManager installed, the CLI can use `nmcli`
for:

- read-only Wi-Fi discovery
- connecting to an SSID with an explicitly supplied password

No password cracking or unauthorized access is implemented.

## Recommended Android architecture

Android UI -> native Wi-Fi service -> local authenticated bridge -> ProSecToolkit
Python engine.

The Python CLI remains useful for reporting, HTTP/TLS analysis, DNS, port
inventory, and other platform-independent functions.
