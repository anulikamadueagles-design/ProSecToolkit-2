# Android build

The repository now contains a real Android Gradle project under `android/`.
It embeds the defensive Python modules using Chaquopy and provides a native
Android UI for authorized web/network assessment functions plus Wi-Fi scan.

The GitHub Actions workflow builds a debug APK on every push to `main` and on
manual dispatch.

Toolchain: Android Gradle Plugin 9.2.1, Gradle 9.4.1, JDK 17, compile/target
SDK 36, Chaquopy 17.0, Python 3.13.

Some desktop-only Python dependencies (such as psutil/scapy) are not installed
in the Android build because they depend on OS facilities unavailable or
unsuitable on Android. The desktop Python toolkit remains complete in the root
project and keeps its full dependency set.
