# Release checklist

- Android native Wi-Fi companion included
- Creator branding included
- Chrome companion skeleton included
- Privacy-policy template included
- Banking module remains simulation-only until an official compliant provider is integrated
- Production signing, store metadata, privacy URL, data-safety declarations and final policy review remain required before public release

Never put bank/provider secret keys in the APK. Use a secure backend and per-user authorization.
