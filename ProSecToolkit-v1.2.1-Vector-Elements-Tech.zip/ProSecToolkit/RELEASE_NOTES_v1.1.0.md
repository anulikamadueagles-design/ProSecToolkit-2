# ProSecToolkit v1.1.0

## Fixed
- Security-header severity model no longer labels missing hardening headers as high severity by default.
- Positive/clean observations no longer inflate risk score.
- Module errors are represented as `ERROR`/informational rather than vulnerabilities.
- Reports now include finding status and evidence.
- Android/terminal prompt paste issue is handled more robustly.

## Added
- Explicit `NOT_ESTABLISHED` coverage for SQL injection, XSS, authentication bypass, RCE, SSRF, account takeover, and data exposure.
- Wi-Fi discovery and authorized-credential connection helpers where supported by the host OS.
- Local banking simulator with PIN authorization and transaction history; no real-money connectivity.
- Regression tests for the new behavior.
