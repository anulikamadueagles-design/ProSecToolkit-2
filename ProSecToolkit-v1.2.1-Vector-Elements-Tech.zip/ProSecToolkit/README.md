# ProSecToolkit

A defensive security assessment toolkit for scanning, analyzing, and
reporting on the security posture of systems and networks **you own or
are explicitly authorized to assess.**

> **Authorized Use Only**
> ProSecToolkit must only be used against systems, networks, and
> applications that you own or for which you have explicit, documented
> authorization to test. Unauthorized scanning or assessment of
> third-party systems may be illegal in your jurisdiction. The
> application will not proceed past its startup banner until you
> confirm this.
>
> ProSecToolkit intentionally does **not** implement malware,
> credential theft, persistence mechanisms, unauthorized exploitation,
> privilege escalation, password cracking, or any other offensive
> capability. It is a passive/active *assessment and reporting* tool,
> not an attack tool.

---

## Features

- **Network Tools** — local host discovery (ICMP ping sweep), configurable
  TCP port scanning, DNS/reverse-DNS lookups, basic latency checks.
- **Web Analysis** — HTTP response and redirect-chain analysis, security
  header inspection, TLS protocol/cipher analysis, certificate
  expiration checks.
- **System Information** — hostname, local IP addresses, network
  interfaces, OS details, Wi-Fi connection info.
- **Defensive Analysis** — aggregates raw scan output into standardized
  findings (missing headers, weak TLS, expiring certs, risky open
  ports) and computes an overall Low/Medium/High risk score with a
  plain-language explanation.
- **Reporting** — generates timestamped text, HTML, and PDF reports
  with an executive summary, technical findings table, and prioritized
  remediation recommendations. Past assessments are logged to a local
  SQLite database for history/review.
- **CLI** — interactive, colorized, menu-driven interface with a
  persistent `config.ini` for defaults (assessor name, org name, port
  range, etc.).

## Project Structure

```
ProSecToolkit/
├── main.py                  # Entry point
├── config.py                # App-wide defaults & paths
├── requirements.txt
├── core/
│   ├── menu.py               # Interactive CLI menu system
│   ├── logger.py             # Timestamped file + console logging
│   ├── database.py           # SQLite assessment history
│   ├── config_manager.py     # Reads/writes config.ini
│   ├── colors.py             # ANSI color helpers
│   └── utils.py               # Shared helpers (IP/CIDR validation, etc.)
├── modules/
│   ├── network_scan.py        # Host discovery (ping sweep)
│   ├── port_scan.py           # TCP connect-scan
│   ├── dns_tools.py           # DNS / reverse DNS / latency
│   ├── http_analyzer.py       # HTTP response & redirect analysis
│   ├── tls_analyzer.py        # TLS protocol/cipher analysis
│   ├── security_headers.py    # Missing-header detection
│   ├── wifi_info.py           # Local Wi-Fi adapter info
│   ├── system_info.py         # Hostname / interfaces / OS info
│   ├── certificate_check.py   # Certificate expiry/validity
│   ├── config_audit.py        # Aggregates raw findings into audit items
│   ├── risk_score.py          # Low/Medium/High scoring
│   └── report_generator.py    # TXT / HTML / PDF report generation
├── reports/                  # Generated reports land here
├── logs/                     # Timestamped application logs
└── assets/                   # Static assets (e.g. report styling)
```

## Installation

Requires **Python 3.11+**.

```bash
git clone <this-repo>
cd ProSecToolkit
pip install -r requirements.txt
```

### Platform Notes

- **Windows / Linux / macOS**: all features supported. Some port/host
  discovery behavior may require running with elevated privileges
  depending on OS firewall rules.
- **Android (Pydroid 3)**: core scanning, DNS, HTTP/TLS, and reporting
  work via the standard library and `requests`/`dnspython`. Wi-Fi info
  and `scapy`-based ARP discovery are generally **not available** on
  Android and will report an informative error rather than crashing.
  Host discovery falls back to ICMP ping sweeps, which use the system
  `ping` binary and work in most Pydroid environments.
- `scapy` in `requirements.txt` is optional — the toolkit works fully
  without it; it's only used opportunistically for enhanced discovery
  where available.

## Usage

```bash
python main.py
```

On launch, you'll see the authorization banner. Type `yes` to confirm
you're authorized to assess your intended target(s), then use the
numbered menu to:

1. **Network Tools** — discover hosts on a CIDR range, port-scan a host,
   run DNS/reverse-DNS lookups, or check latency.
2. **Web Analysis** — analyze an HTTP(S) endpoint, check security
   headers, inspect TLS configuration, or check certificate expiry.
3. **System Information** — view local hostname, IPs, interfaces, OS,
   and Wi-Fi info.
4. **Run Full Assessment** — the one-stop option: scans common ports,
   analyzes HTTP/TLS/certificate, aggregates findings, computes a risk
   score, and writes TXT/HTML/PDF reports to `reports/`.
5. **Reports** — view a history of past assessments (stored in
   `prosectoolkit.db`).
6. **Settings** — set your assessor/organization name and default port
   scan range (persisted to `config.ini`).

### Example: Full Assessment

```
Select an option: 4
Target hostname (e.g. example.com): my-own-server.example
Running full assessment against my-own-server.example...
  [1/4] Port scanning common ports...
  [2/4] Analyzing HTTP/HTTPS...
  [3/4] Checking TLS configuration and certificate...
  [4/4] Scoring risk and generating report...

Overall Risk: MEDIUM (score: 12)
1 high-severity, 1 medium-severity, and 2 low-severity finding(s)...

Reports generated:
  TXT: reports/my-own-server.example_20260101_120000.txt
  HTML: reports/my-own-server.example_20260101_120000.html
  PDF: reports/my-own-server.example_20260101_120000.pdf
```

## Configuration

Settings persist to `config.ini` (created on first run). You can edit
it directly or use the in-app **Settings** menu. Configurable values
include port scan range/timeouts/thread count, DNS/HTTP/TLS timeouts,
report output formats, and assessor/organization name for report
headers.

## Running Tests

The test suite covers pure logic — risk scoring, header evaluation,
finding aggregation, input validation, and text report generation —
without touching the network, so it runs the same everywhere.

```bash
pip install pytest   # already included in requirements.txt
pytest tests/ -v
```

Network-dependent modules (`port_scan`, `dns_tools`, `http_analyzer`,
`tls_analyzer`, `certificate_check`, `network_scan`) aren't covered by
automated tests, since exercising them meaningfully requires a real
target and would make the suite flaky/slow. Verify those manually
against a host you own — see "Usage" above.

## Extending ProSecToolkit

The `modules/` package is designed as a simple plugin surface: each
module exposes plain functions that take `(target, config, logger,
...)` and return a dataclass result. To add a new check:

1. Create `modules/your_module.py` following the existing pattern.
2. Add any new finding types to `modules/config_audit.py` so they flow
   into risk scoring and reporting automatically.
3. Wire a menu entry in `core/menu.py`.

## License / Disclaimer

This tool is provided for legitimate, authorized security assessment
and educational purposes only. The authors are not responsible for
misuse. Always obtain written authorization before assessing any
system or network you do not own.

## v1.1 additions

### Wi-Fi discovery and authorized connection

`modules/wifi_manager.py` adds read-only nearby Wi-Fi discovery and an authorized connection helper.
The connection helper requires credentials supplied by the operator and does not implement password cracking,
credential capture, deauthentication, or access-control bypass.

- Linux: uses NetworkManager (`nmcli`) when available.
- Windows: discovery uses `netsh`; programmatic connection requires an existing authorized WLAN profile.
- Android/Pydroid: the Python CLI does not have the same native Wi-Fi permissions/APIs as an Android APK. The module therefore reports this limitation rather than pretending it can connect. A native Android front end/bridge is required for reliable Android Wi-Fi scanning/connection.

### Banking simulator

`modules/banking_simulator.py` provides a local, authorization-protected **simulation only**. It never connects to a bank or moves real money.
It supports test accounts, balances, PIN authorization, simulated transfers, transaction IDs, and history. Real banking transfers must remain inside the bank's official authenticated application/API and are not implemented by this toolkit.

### Assessment coverage

Full reports explicitly mark the following as `NOT_ESTABLISHED` rather than claiming they were tested:

- SQL injection
- XSS
- Authentication bypass
- RCE
- SSRF
- Account takeover
- Data exposure

`NOT_ESTABLISHED` and module errors do not increase the risk score. Missing security headers are treated as low-priority hardening observations rather than automatic high-severity vulnerabilities.

## Android application (v1.2.1)

The repository includes a native Android project in `android/`. It embeds the
core defensive Python analysis modules with Chaquopy and provides a branded
mobile UI for authorized HTTP/header/TLS/certificate/DNS/port analysis plus
native Wi-Fi scanning. The desktop CLI remains in the repository root.

The Android build intentionally excludes desktop-only Python dependencies such
as `psutil` and `scapy`; the Android app does not claim those desktop features
are available. Real banking is not implemented: the banking component remains
a local simulator until an approved official banking/open-banking integration
is selected.
