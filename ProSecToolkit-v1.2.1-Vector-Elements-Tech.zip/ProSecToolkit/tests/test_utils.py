"""Tests for core/utils.py — pure logic, no network calls."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.utils import (
    format_bytes, is_private_network, is_valid_cidr, is_valid_ip, truncate,
)


def test_is_valid_ip_accepts_ipv4():
    assert is_valid_ip("192.168.1.1") is True


def test_is_valid_ip_accepts_ipv6():
    assert is_valid_ip("::1") is True


def test_is_valid_ip_rejects_garbage():
    assert is_valid_ip("not-an-ip") is False
    assert is_valid_ip("999.999.999.999") is False


def test_is_valid_cidr_accepts_network():
    assert is_valid_cidr("192.168.1.0/24") is True


def test_is_valid_cidr_rejects_garbage():
    assert is_valid_cidr("not-a-network") is False


def test_is_private_network_flags_rfc1918():
    assert is_private_network("192.168.1.0/24") is True
    assert is_private_network("10.0.0.0/8") is True


def test_is_private_network_flags_loopback():
    assert is_private_network("127.0.0.1") is True


def test_is_private_network_rejects_public_ranges():
    assert is_private_network("8.8.8.8/32") is False


def test_is_private_network_handles_invalid_input():
    assert is_private_network("not-a-network") is False


def test_format_bytes_scales_units():
    assert format_bytes(500) == "500.0 B"
    assert format_bytes(2048) == "2.0 KB"
    assert format_bytes(1024 ** 3) == "1.0 GB"


def test_truncate_short_text_unchanged():
    assert truncate("hello", max_len=10) == "hello"


def test_truncate_long_text_gets_ellipsis():
    result = truncate("a" * 100, max_len=10)
    assert len(result) == 10
    assert result.endswith("…")
