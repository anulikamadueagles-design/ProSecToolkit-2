"""Tests for modules/security_headers.py — pure logic, no network calls."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.security_headers import evaluate_headers, summarize


def test_all_headers_present_yields_no_missing_findings():
    headers = {
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
        "Content-Security-Policy": "default-src 'self'",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "geolocation=()",
    }
    findings = evaluate_headers(headers)
    assert all(f.present for f in findings)
    summary = summarize(findings)
    assert summary == {"LOW": 0, "MEDIUM": 0, "HIGH": 0}


def test_empty_headers_flags_all_checklist_items_missing():
    findings = evaluate_headers({})
    assert all(not f.present for f in findings)
    # Every missing item should carry a non-empty recommendation.
    assert all(f.recommendation for f in findings)


def test_missing_hsts_and_csp_are_high_severity():
    findings = evaluate_headers({})
    by_header = {f.header: f for f in findings}
    assert by_header["Strict-Transport-Security"].severity == "LOW"
    assert by_header["Content-Security-Policy"].severity == "LOW"


def test_header_matching_is_case_insensitive():
    # Servers may send headers in any case; keys should still match.
    headers = {"strict-transport-security": "max-age=63072000"}
    findings = evaluate_headers(headers)
    hsts = next(f for f in findings if f.header == "Strict-Transport-Security")
    assert hsts.present is True
    assert hsts.value == "max-age=63072000"


def test_summarize_counts_missing_by_severity():
    # Missing everything -> 2 HIGH, 2 MEDIUM, 2 LOW per the current checklist
    findings = evaluate_headers({})
    summary = summarize(findings)
    assert summary["HIGH"] == 0
    assert summary["MEDIUM"] == 0
    assert summary["LOW"] == 6


def test_present_header_reports_recommendation_as_satisfied():
    headers = {"X-Frame-Options": "SAMEORIGIN"}
    findings = evaluate_headers(headers)
    xfo = next(f for f in findings if f.header == "X-Frame-Options")
    assert xfo.present is True
    assert xfo.recommendation == "Present."
