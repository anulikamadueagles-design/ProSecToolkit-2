"""Tests for modules/risk_score.py — pure logic, no network calls."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.config_audit import AuditFinding
from modules.risk_score import calculate_risk


def _finding(severity: str) -> AuditFinding:
    return AuditFinding(
        category="Test", description=f"{severity} finding", severity=severity,
        recommendation="Do the thing.",
    )


def test_no_findings_is_low_risk():
    result = calculate_risk([])
    assert result.level == "LOW"
    assert result.score == 0
    assert result.severity_counts == {"LOW": 0, "MEDIUM": 0, "HIGH": 0}


def test_single_low_finding_stays_low():
    result = calculate_risk([_finding("LOW")])
    assert result.level == "LOW"
    assert result.score == 1


def test_multiple_medium_findings_reach_medium():
    # 2 x MEDIUM (5 pts each) = 10, which meets the MEDIUM threshold
    result = calculate_risk([_finding("MEDIUM"), _finding("MEDIUM")])
    assert result.score == 10
    assert result.level == "MEDIUM"


def test_high_findings_reach_high():
    # 2 x HIGH (15 pts each) = 30, which meets the HIGH threshold
    result = calculate_risk([_finding("HIGH"), _finding("HIGH")])
    assert result.score == 30
    assert result.level == "HIGH"


def test_single_high_finding_is_not_yet_high_level():
    # 1 HIGH = 15 pts -> below the 30-point HIGH threshold, so MEDIUM
    result = calculate_risk([_finding("HIGH")])
    assert result.score == 15
    assert result.level == "MEDIUM"


def test_severity_counts_are_accurate():
    findings = [_finding("HIGH"), _finding("MEDIUM"), _finding("LOW"), _finding("LOW")]
    result = calculate_risk(findings)
    assert result.severity_counts == {"HIGH": 1, "MEDIUM": 1, "LOW": 2}


def test_unknown_severity_is_treated_as_low():
    weird = AuditFinding(category="Test", description="?", severity="WEIRD", recommendation="?")
    result = calculate_risk([weird])
    assert result.severity_counts["LOW"] == 0
    assert result.score == 0


def test_explanation_mentions_counts_and_level():
    findings = [_finding("HIGH"), _finding("LOW")]
    result = calculate_risk(findings)
    assert "1 high-severity" in result.explanation
    assert result.level in result.explanation
