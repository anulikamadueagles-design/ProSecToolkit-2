from modules.config_audit import AuditFinding
from modules.risk_score import calculate_risk
from modules.coverage import get_coverage_findings
from modules.banking_simulator import create_account, get_account, transfer
import modules.banking_simulator as bs


def test_not_established_categories_are_explicit():
    items = get_coverage_findings()
    names = {x['category'] for x in items}
    assert {"SQL injection","XSS","Authentication bypass","RCE","SSRF","Account takeover","Data exposure"} <= names
    assert all(x['status'] == 'NOT_ESTABLISHED' for x in items)


def test_not_established_does_not_raise_risk():
    findings=[AuditFinding(x['category'],x['description'],'INFO',x['recommendation'],x['status']) for x in get_coverage_findings()]
    assert calculate_risk(findings).score == 0


def test_banking_simulator_requires_authorization_and_moves_only_simulated_funds(tmp_path, monkeypatch):
    monkeypatch.setattr(bs, 'DB_PATH', tmp_path / 'sim.db')
    create_account('1001','Alice',100000,'1234')
    create_account('1002','Bob',0,'5678')
    denied=transfer('1001','1002',50000,'0000')
    assert not denied.success
    ok=transfer('1001','1002',50000,'1234')
    assert ok.success
    assert get_account('1001','1234').balance == 50000
    assert get_account('1002','5678').balance == 50000
