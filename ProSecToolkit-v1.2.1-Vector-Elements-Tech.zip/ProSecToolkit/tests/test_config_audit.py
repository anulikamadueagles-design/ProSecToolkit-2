"""Tests for modules/config_audit.py — pure logic, no network calls."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.certificate_check import CertificateInfo
from modules.config_audit import (
    audit_certificate, audit_headers, audit_open_ports, audit_tls, run_full_audit,
)
from modules.port_scan import PortResult
from modules.security_headers import HeaderFinding
from modules.tls_analyzer import TLSFinding


# ---------------------------------------------------------------------
# audit_open_ports
# ---------------------------------------------------------------------
def test_risky_port_open_flags_high_severity():
    findings = audit_open_ports([PortResult(port=3389, open=True, service="RDP")])
    assert any(f.severity == "HIGH" and "3389" in f.description for f in findings)


def test_non_risky_open_port_is_low_severity_summary():
    findings = audit_open_ports([PortResult(port=8000, open=True)])
    assert len(findings) == 1
    assert findings[0].severity == "INFO"


def test_no_open_ports_is_a_clean_low_finding():
    findings = audit_open_ports([])
    assert len(findings) == 1
    assert findings[0].severity == "INFO"
    assert "0 open port" in findings[0].description


# ---------------------------------------------------------------------
# audit_headers
# ---------------------------------------------------------------------
def test_missing_headers_become_findings():
    header_findings = [
        HeaderFinding(header="Content-Security-Policy", present=False, value=None,
                       recommendation="Add a CSP.", severity="HIGH"),
        HeaderFinding(header="X-Frame-Options", present=True, value="DENY",
                       recommendation="Present.", severity="LOW"),
    ]
    findings = audit_headers(header_findings)
    assert len(findings) == 1
    assert findings[0].category == "HTTP Headers"
    assert findings[0].severity == "HIGH"


def test_all_headers_present_yields_clean_finding():
    header_findings = [
        HeaderFinding(header="X-Frame-Options", present=True, value="DENY",
                       recommendation="Present.", severity="LOW"),
    ]
    findings = audit_headers(header_findings)
    assert len(findings) == 1
    assert "security headers" in findings[0].description


# ---------------------------------------------------------------------
# audit_tls
# ---------------------------------------------------------------------
def test_tls_findings_pass_through_with_recommendation():
    tls_findings = [TLSFinding(description="Weak cipher suite negotiated: RC4-MD5.", severity="HIGH")]
    findings = audit_tls(tls_findings)
    assert len(findings) == 1
    assert findings[0].category == "TLS"
    assert findings[0].severity == "HIGH"
    assert findings[0].recommendation  # non-empty


# ---------------------------------------------------------------------
# audit_certificate
# ---------------------------------------------------------------------
def test_expired_certificate_is_high_severity():
    cert = CertificateInfo(host="example.test", port=443, status="expired", days_until_expiry=-5)
    findings = audit_certificate(cert)
    assert findings[0].severity == "HIGH"
    assert "expired 5 day" in findings[0].description


def test_expiring_soon_certificate_is_medium_severity():
    cert = CertificateInfo(host="example.test", port=443, status="expiring_soon", days_until_expiry=10)
    findings = audit_certificate(cert)
    assert findings[0].severity == "MEDIUM"


def test_valid_certificate_is_low_severity():
    cert = CertificateInfo(host="example.test", port=443, status="valid", days_until_expiry=200)
    findings = audit_certificate(cert)
    assert findings[0].severity == "INFO"


def test_certificate_error_is_not_a_vulnerability():
    cert = CertificateInfo(host="example.test", port=443, error="handshake failed")
    findings = audit_certificate(cert)
    assert findings[0].severity == "INFO"
    assert findings[0].status == "ERROR"
    assert "handshake failed" in findings[0].description


# ---------------------------------------------------------------------
# run_full_audit
# ---------------------------------------------------------------------
def test_run_full_audit_combines_all_sections():
    findings = run_full_audit(
        open_ports=[PortResult(port=23, open=True, service="Telnet")],
        header_findings=[HeaderFinding(header="X-Frame-Options", present=False, value=None,
                                        recommendation="Add it.", severity="MEDIUM")],
        tls_findings=[TLSFinding(description="Deprecated protocol.", severity="HIGH")],
        certificate=CertificateInfo(host="x", port=443, status="valid", days_until_expiry=100),
    )
    categories = {f.category for f in findings}
    assert categories == {"Open Ports", "HTTP Headers", "TLS", "Certificate"}


def test_run_full_audit_handles_missing_sections_gracefully():
    # Only ports provided — other sections should simply be skipped, not error.
    findings = run_full_audit(open_ports=[])
    assert all(f.category == "Open Ports" for f in findings)
