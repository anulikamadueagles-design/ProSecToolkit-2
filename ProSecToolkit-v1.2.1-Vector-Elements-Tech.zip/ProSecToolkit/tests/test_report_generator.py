"""
Tests for modules/report_generator.py — text report generation.

Only exercises the text-report path directly (pure file I/O, no network
calls). HTML/PDF generation depend on optional third-party libraries
(jinja2/reportlab) and are covered by the manual smoke test described
in the README rather than here, since they may not always be installed.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import modules.report_generator as report_generator
from config import DEFAULT_CONFIG
from modules.config_audit import AuditFinding
from modules.risk_score import calculate_risk


def _sample_findings() -> list[AuditFinding]:
    return [
        AuditFinding("Open Ports", "Port 3389 (RDP) is open.", "HIGH",
                     "Disable RDP or restrict via firewall/VPN."),
        AuditFinding("HTTP Headers", "Missing header: X-Frame-Options", "MEDIUM",
                     "Add X-Frame-Options: DENY."),
    ]


def test_generate_text_report_writes_file(tmp_path, monkeypatch):
    monkeypatch.setattr(report_generator, "REPORTS_DIR", tmp_path)

    findings = _sample_findings()
    risk = calculate_risk(findings)
    ctx = report_generator.build_context("test-target.internal", DEFAULT_CONFIG, findings, risk)

    path = report_generator.generate_text_report(ctx)

    assert path.exists()
    assert path.parent == tmp_path
    content = path.read_text(encoding="utf-8")
    assert "test-target.internal" in content
    assert risk.level in content
    assert "Port 3389 (RDP) is open." in content


def test_generate_text_report_lists_high_and_medium_in_remediation(tmp_path, monkeypatch):
    monkeypatch.setattr(report_generator, "REPORTS_DIR", tmp_path)

    findings = _sample_findings()
    risk = calculate_risk(findings)
    ctx = report_generator.build_context("test-target.internal", DEFAULT_CONFIG, findings, risk)

    path = report_generator.generate_text_report(ctx)
    content = path.read_text(encoding="utf-8")

    remediation_section = content.split("RECOMMENDED REMEDIATION")[1]
    assert "Disable RDP" in remediation_section
    assert "Add X-Frame-Options" in remediation_section


def test_generate_text_report_with_no_findings(tmp_path, monkeypatch):
    monkeypatch.setattr(report_generator, "REPORTS_DIR", tmp_path)

    risk = calculate_risk([])
    ctx = report_generator.build_context("empty-target.internal", DEFAULT_CONFIG, [], risk)

    path = report_generator.generate_text_report(ctx)
    content = path.read_text(encoding="utf-8")
    assert "LOW" in content


def test_report_filename_sanitizes_target(tmp_path, monkeypatch):
    monkeypatch.setattr(report_generator, "REPORTS_DIR", tmp_path)

    risk = calculate_risk([])
    # A target with characters that shouldn't land raw in a filename.
    ctx = report_generator.build_context("http://weird target!.com", DEFAULT_CONFIG, [], risk)
    path = report_generator.generate_text_report(ctx)

    assert path.exists()
    assert " " not in path.name
    assert "!" not in path.name
