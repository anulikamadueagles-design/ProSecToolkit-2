from modules.android_wifi import is_android, scan_wifi, connect_authorized


def test_empty_connection_inputs_are_rejected():
    ok, msg = connect_authorized("", "password")
    assert ok is False
    assert "SSID" in msg


def test_empty_password_is_rejected():
    ok, msg = connect_authorized("MyTestWifi", "")
    assert ok is False
    assert "password" in msg


def test_scan_returns_defined_shape():
    networks, error = scan_wifi()
    assert isinstance(networks, list)
    assert error is None or isinstance(error, str)
