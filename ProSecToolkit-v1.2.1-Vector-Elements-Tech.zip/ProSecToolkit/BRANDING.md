# ProSecToolkit — Vectors Element Tech

Created by: David Kamsi Elvis
Publisher/Brand: Vectors Element Tech
Version: 1.2.0

Professional defensive security assessment toolkit for authorized testing.
